% deConfUSIon finalizer v2: safe title rename, JM atlas auto-prepare, FC hotfix, cleanup inventory
%
% Usage:
%   run('D:\Github\HUMOR-Analysis-Tool\deConfUSIon_finalize_cleanup_and_atlas_auto_v2.m')
%
% This script only archives files into backups/. It does not permanently delete files.

clear; clc;
ROOT = 'D:\Github\HUMOR-Analysis-Tool';
if exist(ROOT,'dir') ~= 7
    warning('Default ROOT not found: %s', ROOT);
    ROOT = pwd;
    fprintf('Using current folder instead: %s\n', ROOT);
end
if exist(ROOT,'dir') ~= 7
    error('Toolbox root does not exist. Edit ROOT at the top of this script.');
end
if exist(fullfile(ROOT,'run_fusi_studio.m'),'file') ~= 2
    error('run_fusi_studio.m not found in %s. Put this patch in the toolbox root or edit ROOT.', ROOT);
end

PATCH_DIR = fileparts(mfilename('fullpath'));
if isempty(PATCH_DIR), PATCH_DIR = pwd; end

ts = datestr(now,'yyyymmdd_HHMMSS');
backupDir = fullfile(ROOT,'backups',['deConfUSIon_finalize_v2_' ts]);
localEnsureDir(backupDir);
logFile = fullfile(backupDir,'finalize_v2_log.txt');
localLog(logFile, sprintf('deConfUSIon finalizer v2 started: %s', datestr(now)));
localLog(logFile, sprintf('ROOT: %s', ROOT));
localLog(logFile, sprintf('PATCH_DIR: %s', PATCH_DIR));

try
    tt = timerfindall;
    if ~isempty(tt)
        try, stop(tt); catch, end
        try, delete(tt); catch, end
    end
catch
end
rehash; clear functions;

%% 1) Install atlas tools and support files
atlasDir = fullfile(ROOT,'atlas_tools');
localEnsureDir(atlasDir);

supportFiles = {'rgb2acr.xlsx','list_selected_regions.txt','matlab_functions.rar'};
for k = 1:numel(supportFiles)
    localCopySupport(ROOT, PATCH_DIR, atlasDir, supportFiles{k}, logFile);
end

atlasHelpers = { ...
    'readFileList.m', ...
    'save_correct_colors.m', ...
    'deConfUSIon_apply_rgb2acr.m', ...
    'deConfUSIon_prepare_atlas.m', ...
    'deConfUSIon_fc_jm_order.m', ...
    'deConfUSIon_reorder_FC_by_list.m'};
for k = 1:numel(atlasHelpers)
    localCopyFromPatch(PATCH_DIR, atlasDir, atlasHelpers{k}, logFile, true);
end
try, addpath(atlasDir,'-begin'); catch, end
localLog(logFile, 'Installed/refreshed atlas_tools.');

%% 2) Restore essential external FC helpers if previous cleanup archived them
fcHelpers = { ...
    'HUMOR_FC_build_slice_bundle.m', ...
    'HUMOR_FC_compare_slice_note.m', ...
    'HUMOR_FC_find_stepmotor_txt_names.m', ...
    'HUMOR_FC_force_layout.m', ...
    'HUMOR_FC_label_mask_for_slice.m', ...
    'HUMOR_FC_make_slice_roi_result.m', ...
    'HUMOR_FC_read_region_names_file.m', ...
    'HUMOR_FC_remember_layout.m', ...
    'HUMOR_FC_slice_keep_indices.m', ...
    'HUMOR_FC_stepmotor_folder_payload.m', ...
    'HUMOR_FC_stepmotor_read_folder.m', ...
    'fc_compare_slice_note.m', ...
    'fc_label_mask_for_slice.m', ...
    'fc_region_names_from_region_struct.m', ...
    'fc_slice_filter_text.m'};
for k = 1:numel(fcHelpers)
    dst = fullfile(ROOT,fcHelpers{k});
    if exist(dst,'file') ~= 2
        localCopyFromPatch(PATCH_DIR, ROOT, fcHelpers{k}, logFile, false);
    end
end

%% 3) Repair previous bad FunctionalConnectivity integration
fcFile = fullfile(ROOT,'FunctionalConnectivity.m');
if exist(fcFile,'file') == 2
    localBackupFile(fcFile, backupDir, ROOT);
    fcTxt = localReadText(fcFile);
    fcTxt = localNormalizeNewlines(fcTxt);

    markerStart = '%% deConfUSIon integrated FunctionalConnectivity helper block START';
    markerEnd = '%% deConfUSIon integrated FunctionalConnectivity helper block END';
    fcTxt2 = localRemoveMarkedBlock(fcTxt, markerStart, markerEnd);
    if ~strcmp(fcTxt2,fcTxt)
        fcTxt = fcTxt2;
        localLog(logFile, 'Removed old integrated FC helper block to fix duplicate localGet errors.');
    end

    % Add JM ordering to normal square ROI heatmap sorting.
    if isempty(strfind(fcTxt,'deConfUSIon_fc_jm_order(labelsDisplay,names)'))
        oldBlock = [ ...
            '        otherwise' char(10) ...
            '            [~,ord2] = sort(labelsDisplay);' char(10)];
        newBlock = [ ...
            '        otherwise' char(10) ...
            '            try' char(10) ...
            '                [ord2,okJM] = deConfUSIon_fc_jm_order(labelsDisplay,names);' char(10) ...
            '                if ~okJM, [~,ord2] = sort(labelsDisplay); end' char(10) ...
            '            catch' char(10) ...
            '                [~,ord2] = sort(labelsDisplay);' char(10) ...
            '            end' char(10)];
        if ~isempty(strfind(fcTxt, oldBlock))
            fcTxt = strrep(fcTxt, oldBlock, newBlock);
            localLog(logFile, 'Added JM ordering fallback to normal FC heatmap order.');
        else
            localLog(logFile, 'JM normal FC ordering patch skipped: expected sort block not found.');
        end
    else
        localLog(logFile, 'JM normal FC ordering already present.');
    end

    % Add JM ordering to left-vs-right rectangular heatmap sorting.
    if isempty(strfind(fcTxt,'deConfUSIon_fc_jm_order(labels0(leftIdx),namesL0)'))
        oldBlock = [ ...
            '        [~,ordL] = sort(cleanL);' char(10) ...
            '        [~,ordR] = sort(cleanR);' char(10)];
        newBlock = [ ...
            '        try' char(10) ...
            '            [ordL,okJML] = deConfUSIon_fc_jm_order(labels0(leftIdx),namesL0);' char(10) ...
            '        catch' char(10) ...
            '            okJML = false;' char(10) ...
            '        end' char(10) ...
            '        if ~okJML, [~,ordL] = sort(cleanL); end' char(10) ...
            '        try' char(10) ...
            '            [ordR,okJMR] = deConfUSIon_fc_jm_order(labels0(rightIdx),namesR0);' char(10) ...
            '        catch' char(10) ...
            '            okJMR = false;' char(10) ...
            '        end' char(10) ...
            '        if ~okJMR, [~,ordR] = sort(cleanR); end' char(10)];
        if ~isempty(strfind(fcTxt, oldBlock))
            fcTxt = strrep(fcTxt, oldBlock, newBlock);
            localLog(logFile, 'Added JM ordering fallback to left-vs-right FC heatmap order.');
        else
            localLog(logFile, 'JM left-vs-right ordering patch skipped: expected block not found.');
        end
    else
        localLog(logFile, 'JM left-vs-right ordering already present.');
    end

    localWriteText(fcFile, fcTxt);
end

%% 4) Make JM atlas preparation automatic in atlas registration and segmentation
prepLines = { ...
    ''; ...
    '% deConfUSIon JM atlas auto-prepare START'; ...
    'try'; ...
    '    rootDCU = fileparts(mfilename(''fullpath''));'; ...
    '    atlasToolsDCU = fullfile(rootDCU,''atlas_tools'');'; ...
    '    if exist(atlasToolsDCU,''dir'') == 7, addpath(atlasToolsDCU,''-begin''); end'; ...
    '    atlas = deConfUSIon_prepare_atlas(atlas, atlasPath);'; ...
    'catch ME_atlas'; ...
    '    warning(''deConfUSIon:AtlasAutoPrepare'', ''JM atlas auto-prepare skipped: %s'', ME_atlas.message);'; ...
    'end'; ...
    '% deConfUSIon JM atlas auto-prepare END'; ...
    ''};
prepBlock = localLinesToText(prepLines);

coregFiles = {'coreg_3d.m','coreg_coronal_2d.m'};
for k = 1:numel(coregFiles)
    f = fullfile(ROOT,coregFiles{k});
    if exist(f,'file') == 2
        localInsertAfterOnce(f, 'atlas = SAtlas.atlas;', prepBlock, 'deConfUSIon JM atlas auto-prepare START', backupDir, ROOT, logFile);
    end
end

segFile = fullfile(ROOT,'Segmentation.m');
if exist(segFile,'file') == 2
    localInsertAfterOnce(segFile, 'atlas = S.atlas;', prepBlock, 'deConfUSIon JM atlas auto-prepare START', backupDir, ROOT, logFile);
end

%% 5) Safe visible title rename only
localSafeTitleReplace(fullfile(ROOT,'fusi_studio_GUI.m'), backupDir, ROOT, logFile);
localSafeTitleReplace(fullfile(ROOT,'addLog.m'), backupDir, ROOT, logFile);
localSafeTitleReplace(fullfile(ROOT,'buildFooterLabel.m'), backupDir, ROOT, logFile);
localSafeTitleReplace(fullfile(ROOT,'run_fusi_studio.m'), backupDir, ROOT, logFile);

%% 6) Ensure launchers add atlas_tools path
launcherText = [ ...
    'function deConfUSIon()' char(10) ...
    'root = fileparts(mfilename(''fullpath''));' char(10) ...
    'if isempty(root), root = pwd; end' char(10) ...
    'addpath(root,''-begin'');' char(10) ...
    'atlasTools = fullfile(root,''atlas_tools'');' char(10) ...
    'if exist(atlasTools,''dir'') == 7, addpath(atlasTools,''-begin''); end' char(10) ...
    'run_deConfUSIon;' char(10) ...
    'end' char(10)];
localWriteText(fullfile(ROOT,'deConfUSIon.m'), launcherText);

runLauncherText = [ ...
    'function run_deConfUSIon()' char(10) ...
    'root = fileparts(mfilename(''fullpath''));' char(10) ...
    'if isempty(root), root = pwd; end' char(10) ...
    'addpath(root,''-begin'');' char(10) ...
    'atlasTools = fullfile(root,''atlas_tools'');' char(10) ...
    'if exist(atlasTools,''dir'') == 7, addpath(atlasTools,''-begin''); end' char(10) ...
    'run_fusi_studio;' char(10) ...
    'end' char(10)];
localWriteText(fullfile(ROOT,'run_deConfUSIon.m'), runLauncherText);
localLog(logFile, 'Wrote/refreshed deConfUSIon launchers.');

% Also make direct run_fusi_studio calls aware of atlas_tools.
runFile = fullfile(ROOT,'run_fusi_studio.m');
if exist(runFile,'file') == 2
    txt = localNormalizeNewlines(localReadText(runFile));
    if isempty(strfind(txt,'atlasToolsDCU = fullfile(root,''atlas_tools'');'))
        localBackupFile(runFile, backupDir, ROOT);
        anchor = 'try' ;
        addRootBlock = [ ...
            'try' char(10) ...
            '    atlasToolsDCU = fullfile(root,''atlas_tools'');' char(10) ...
            '    if exist(atlasToolsDCU,''dir'') == 7, addpath(atlasToolsDCU,''-begin''); end' char(10) ...
            'catch' char(10) ...
            'end' char(10) char(10) ...
            'try'];
        firstTry = strfind(txt, anchor);
        if ~isempty(firstTry)
            txt = [txt(1:firstTry(1)-1) addRootBlock txt(firstTry(1)+numel(anchor):end)];
            localWriteText(runFile, txt);
            localLog(logFile, 'Added atlas_tools path setup to run_fusi_studio.m.');
        end
    end
end

%% 7) Restore popup timer only if it was broken by a previous visible-branding pass
popupFiles = {'HUMoR_popup_autofit_timer.m','HUMoR_popup_autofit_apply.m','HUMoR_popup_polish_now.m'};
for k = 1:numel(popupFiles)
    f = fullfile(ROOT,popupFiles{k});
    if exist(f,'file') == 2
        txt = localReadText(f);
        bad = ~isempty(strfind(txt,'function deConfUSIon_popup_')) || ~isempty(strfind(txt,'deConfUSIon_popup_autofit_timer('));
        if bad
            localBackupFile(f, backupDir, ROOT);
            localCopyFromPatch(PATCH_DIR, ROOT, popupFiles{k}, logFile, true);
            localLog(logFile, sprintf('Restored popup helper after unsafe rename: %s', popupFiles{k}));
        end
    else
        localCopyFromPatch(PATCH_DIR, ROOT, popupFiles{k}, logFile, false);
    end
end

%% 8) Archive patch clutter and only clearly unreferenced helper aliases
clutterDir = fullfile(backupDir,'archived_patch_clutter');
localEnsureDir(clutterDir);
clutter = { ...
    'deConfUSIon_cleanup_patch.m', ...
    'deConfUSIon_repair_after_cleanup.m', ...
    'deConfUSIon_safe_hotfix_cleanup_atlas.m', ...
    'deConfUSIon_finalize_cleanup_and_atlas_auto.m', ...
    'deConfUSIon_cleanup_report.md', ...
    'deConfUSIon_safe_hotfix_package.zip', ...
    'deConfUSIon_finalize_package.zip', ...
    'rgb2acr.xlsx', ...
    'list_selected_regions.txt', ...
    'matlab_functions.rar'};
for k = 1:numel(clutter)
    f = fullfile(ROOT,clutter{k});
    if exist(f,'file') == 2
        try
            movefile(f, fullfile(clutterDir,clutter{k}), 'f');
            localLog(logFile, sprintf('Archived patch clutter: %s', clutter{k}));
        catch ME
            localLog(logFile, sprintf('Could not archive patch clutter %s: %s', clutter{k}, ME.message));
        end
    end
end

% Archive unneeded package folders, but never the current backup folder.
folderClutter = {'deConfUSIon_safe_hotfix_package','deConfUSIon_finalize_package'};
for k = 1:numel(folderClutter)
    f = fullfile(ROOT,folderClutter{k});
    if exist(f,'dir') == 7
        try
            movefile(f, fullfile(clutterDir,folderClutter{k}), 'f');
            localLog(logFile, sprintf('Archived patch folder: %s', folderClutter{k}));
        catch ME
            localLog(logFile, sprintf('Could not archive patch folder %s: %s', folderClutter{k}, ME.message));
        end
    end
end

helperArchive = fullfile(backupDir,'archived_unref_helpers');
localEnsureDir(helperArchive);
maybeUnused = {'fc_find_stepmotor_name_source.m','fc_slice_keep_indices_from_meta.m'};
for k = 1:numel(maybeUnused)
    f = fullfile(ROOT,maybeUnused{k});
    if exist(f,'file') == 2
        [~,nameOnly] = fileparts(f);
        nref = localReferenceCount(ROOT, nameOnly, maybeUnused{k});
        if nref == 0
            try
                movefile(f, fullfile(helperArchive,maybeUnused{k}), 'f');
                localLog(logFile, sprintf('Archived unreferenced helper alias: %s', maybeUnused{k}));
            catch ME
                localLog(logFile, sprintf('Could not archive %s: %s', maybeUnused{k}, ME.message));
            end
        else
            localLog(logFile, sprintf('Kept referenced helper alias: %s (%d reference(s))', maybeUnused{k}, nref));
        end
    end
end

%% 9) Write remaining HUMOR/HUMoR inventory instead of deleting active compatibility layer
invFile = fullfile(backupDir,'remaining_HUMOR_files_inventory.txt');
localWriteHumorInventory(ROOT, invFile);
localLog(logFile, sprintf('Wrote HUMOR/HUMoR inventory: %s', invFile));

rehash; clear functions;

fprintf('\nDONE. deConfUSIon finalizer v2 completed.\n');
fprintf('Backups/log: %s\n', backupDir);
fprintf('Start toolbox with: deConfUSIon\n\n');

%% =============================== local helpers ===============================
function localEnsureDir(d)
if exist(d,'dir') ~= 7
    mkdir(d);
end
end

function localLog(logFile, msg)
try
    fid = fopen(logFile,'a');
    if fid >= 0
        fprintf(fid,'%s\n', msg);
        fclose(fid);
    end
catch
end
try, fprintf('%s\n', msg); catch, end
end

function txt = localReadText(f)
fid = fopen(f,'r');
if fid < 0, error('Could not read file: %s', f); end
c = onCleanup(@() fclose(fid)); %#ok<NASGU>
txt = fread(fid,'*char')';
end

function localWriteText(f, txt)
fid = fopen(f,'w');
if fid < 0, error('Could not write file: %s', f); end
c = onCleanup(@() fclose(fid)); %#ok<NASGU>
fwrite(fid, txt, 'char');
end

function txt = localNormalizeNewlines(txt)
txt = strrep(txt, sprintf('\r\n'), sprintf('\n'));
txt = strrep(txt, sprintf('\r'), sprintf('\n'));
end

function txt = localLinesToText(lines)
txt = '';
for i = 1:numel(lines)
    txt = [txt lines{i} char(10)]; %#ok<AGROW>
end
end

function localBackupFile(f, backupDir, root)
if exist(f,'file') ~= 2, return; end
try
    rel = strrep(f, root, '');
    if ~isempty(rel) && (rel(1) == filesep || rel(1) == '/' || rel(1) == '\')
        rel = rel(2:end);
    end
    rel = strrep(rel,':','_');
    dst = fullfile(backupDir,'before_patch',rel);
    p = fileparts(dst);
    if exist(p,'dir') ~= 7, mkdir(p); end
    copyfile(f,dst,'f');
catch
end
end

function localCopySupport(root, patchDir, atlasDir, fileName, logFile)
src = fullfile(patchDir,fileName);
if exist(src,'file') ~= 2
    src = fullfile(root,fileName);
end
if exist(src,'file') == 2
    try
        copyfile(src, fullfile(atlasDir,fileName), 'f');
        localLog(logFile, sprintf('Copied support file to atlas_tools: %s', fileName));
    catch ME
        localLog(logFile, sprintf('Could not copy support file %s: %s', fileName, ME.message));
    end
else
    localLog(logFile, sprintf('Support file not found, skipped: %s', fileName));
end
end

function localCopyFromPatch(patchDir, dstDir, fileName, logFile, overwrite)
src = fullfile(patchDir,fileName);
dst = fullfile(dstDir,fileName);
if exist(src,'file') ~= 2
    localLog(logFile, sprintf('Patch file missing, could not copy: %s', fileName));
    return;
end
if exist(dst,'file') == 2 && ~overwrite
    return;
end
try
    copyfile(src,dst,'f');
    localLog(logFile, sprintf('Copied patch file: %s', fileName));
catch ME
    localLog(logFile, sprintf('Could not copy %s: %s', fileName, ME.message));
end
end

function txt = localRemoveMarkedBlock(txt, markerStart, markerEnd)
while true
    a = strfind(txt, markerStart);
    b = strfind(txt, markerEnd);
    if isempty(a) || isempty(b), break; end
    a = a(1);
    b = b(find(b > a,1,'first'));
    if isempty(b), break; end
    lineEnd = b + numel(markerEnd) - 1;
    while lineEnd < numel(txt) && txt(lineEnd+1) ~= char(10)
        lineEnd = lineEnd + 1;
    end
    txt = [txt(1:a-1) txt(lineEnd+1:end)];
end
end

function localInsertAfterOnce(f, anchor, block, marker, backupDir, root, logFile)
txt = localNormalizeNewlines(localReadText(f));
if ~isempty(strfind(txt, marker))
    localLog(logFile, sprintf('Already patched: %s', f));
    return;
end
pos = strfind(txt, anchor);
if isempty(pos)
    localLog(logFile, sprintf('Anchor not found in %s: %s', f, anchor));
    return;
end
localBackupFile(f, backupDir, root);
insertAt = pos(1) + numel(anchor);
txt = [txt(1:insertAt) block txt(insertAt+1:end)];
localWriteText(f, txt);
localLog(logFile, sprintf('Inserted JM atlas auto-prepare into: %s', f));
end

function localSafeTitleReplace(f, backupDir, root, logFile)
if exist(f,'file') ~= 2, return; end
txt = localReadText(f);
old = txt;
txt = strrep(txt, '''Name'',''HUMoR Analysis Tool''', '''Name'',''deConfUSIon''');
txt = strrep(txt, '''String'',''HUMoR Analysis Tool''', '''String'',''deConfUSIon''');
txt = strrep(txt, 'tool = ''HUMoR Analysis Tool'';', 'tool = ''deConfUSIon'';');
txt = strrep(txt, 'findall(0,''Type'',''figure'',''Name'',''HUMoR Analysis Tool'')', 'findall(0,''Type'',''figure'',''Name'',''deConfUSIon'')');
txt = strrep(txt, 'HUMoR / fUSI Studio root:', 'deConfUSIon / fUSI Studio root:');
if ~strcmp(txt,old)
    localBackupFile(f, backupDir, root);
    localWriteText(f, txt);
    localLog(logFile, sprintf('Updated safe visible title text in: %s', f));
end
end

function nref = localReferenceCount(root, symbolName, selfFile)
nref = 0;
d = dir(fullfile(root,'*.m'));
for i = 1:numel(d)
    if strcmpi(d(i).name,selfFile), continue; end
    f = fullfile(root,d(i).name);
    try
        txt = localReadText(f);
        nref = nref + numel(strfind(txt, symbolName));
    catch
    end
end
end

function localWriteHumorInventory(root, invFile)
d1 = dir(fullfile(root,'HUMOR*.m'));
d2 = dir(fullfile(root,'HUMoR*.m'));
d = [d1(:); d2(:)];
fid = fopen(invFile,'w');
if fid < 0, return; end
c = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'Remaining HUMOR/HUMoR-named files after deConfUSIon finalizer v2.\n');
fprintf(fid,'These are not deleted automatically because many are still active compatibility functions.\n\n');
for i = 1:numel(d)
    [~,nm] = fileparts(d(i).name);
    nref = localReferenceCount(root,nm,d(i).name);
    fprintf(fid,'%4d refs  %s\n', nref, d(i).name);
end
end
