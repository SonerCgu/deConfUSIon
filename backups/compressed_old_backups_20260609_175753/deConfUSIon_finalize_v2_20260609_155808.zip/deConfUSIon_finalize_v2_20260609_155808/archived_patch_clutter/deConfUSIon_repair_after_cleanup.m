% deConfUSIon repair after over-aggressive cleanup/branding
% Paste/run this in MATLAB. It restores syntactically safe originals from the
% cleanup backup, then re-applies only the FC helper integration and launcher.

clear; clc;
ROOT = 'D:\Github\HUMOR-Analysis-Tool';
if exist(ROOT,'dir') ~= 7
    error('ROOT folder not found. Edit ROOT at the top of this script: %s', ROOT);
end

% Stop old popup timers before touching timer files.
try
    tt = timerfindall;
    if ~isempty(tt)
        try, stop(tt); catch, end
        try, delete(tt); catch, end
    end
catch
end
rehash;
clear functions;

bkRoot = fullfile(ROOT,'backups');
dd = dir(fullfile(bkRoot,'deConfUSIon_cleanup_*'));
if isempty(dd)
    error('No deConfUSIon cleanup backup found under: %s', bkRoot);
end
[~,ix] = max([dd.datenum]);
BAK = fullfile(dd(ix).folder, dd(ix).name);
fprintf('\nUsing cleanup backup:\n%s\n', BAK);

repairDir = fullfile(ROOT,'backups',['repair_after_broken_cleanup_' datestr(now,'yyyymmdd_HHMMSS')]);
if exist(repairDir,'dir') ~= 7, mkdir(repairDir); end
fprintf('Temporary backup of current broken files:\n%s\n\n', repairDir);

% -------------------------------------------------------------------------
% 1) Restore all original files touched by the risky branding/integration pass.
% -------------------------------------------------------------------------
origDir = fullfile(BAK,'originals');
if exist(origDir,'dir') ~= 7
    error('Backup originals folder not found: %s', origDir);
end

stack = {origDir};
origFiles = {};
while ~isempty(stack)
    cur = stack{end};
    stack(end) = [];
    info = dir(cur);
    for k = 1:numel(info)
        nm = info(k).name;
        if strcmp(nm,'.') || strcmp(nm,'..'), continue; end
        p = fullfile(cur,nm);
        if info(k).isdir
            stack{end+1} = p; %#ok<SAGROW>
        else
            origFiles{end+1} = p; %#ok<SAGROW>
        end
    end
end

restored = 0;
for k = 1:numel(origFiles)
    src = origFiles{k};
    rel = src(numel(origDir)+2:end);

    % Keep the new launchers; they are harmless wrappers.
    if strcmpi(rel,'deConfUSIon.m') || strcmpi(rel,'run_deConfUSIon.m')
        continue;
    end

    dst = fullfile(ROOT, rel);

    % Save current broken version before overwriting, just in case.
    if exist(dst,'file') == 2
        dstBak = fullfile(repairDir, rel);
        [pb,~,~] = fileparts(dstBak);
        if exist(pb,'dir') ~= 7, mkdir(pb); end
        try, copyfile(dst, dstBak, 'f'); catch, end
    end

    [pd,~,~] = fileparts(dst);
    if exist(pd,'dir') ~= 7, mkdir(pd); end
    copyfile(src, dst, 'f');
    restored = restored + 1;
end
fprintf('Restored %d original touched file(s).\n', restored);

% -------------------------------------------------------------------------
% 2) Re-apply ONLY the FunctionalConnectivity helper integration.
%    This keeps the root cleaner without doing unsafe text/branding edits.
% -------------------------------------------------------------------------
fcFile = fullfile(ROOT,'FunctionalConnectivity.m');
intDir = fullfile(BAK,'integrated_helpers');
filesToIntegrate = { ...
    'fc_compare_slice_note.m'; ...
    'fc_label_mask_for_slice.m'; ...
    'fc_region_names_from_region_struct.m'; ...
    'fc_slice_filter_text.m'; ...
    'HUMOR_FC_build_slice_bundle.m'; ...
    'HUMOR_FC_force_layout.m'; ...
    'HUMOR_FC_make_slice_roi_result.m'; ...
    'HUMOR_FC_remember_layout.m'; ...
    'HUMOR_FC_slice_keep_indices.m'; ...
    'HUMOR_FC_stepmotor_read_folder.m'};

if exist(fcFile,'file') == 2 && exist(intDir,'dir') == 7
    fcTxt = fileread(fcFile);
    markerStart = '%% deConfUSIon integrated FunctionalConnectivity helper block START';
    markerEnd   = '%% deConfUSIon integrated FunctionalConnectivity helper block END';
    if isempty(strfind(fcTxt, markerStart))
        fcBackup = fullfile(repairDir,'FunctionalConnectivity_before_reintegration.m');
        try, copyfile(fcFile, fcBackup, 'f'); catch, end
        block = sprintf('\n\n%s\n%% Local helper functions integrated from former root-level helper files.\n', markerStart);
        for k = 1:numel(filesToIntegrate)
            src = fullfile(intDir, filesToIntegrate{k});
            if exist(src,'file') == 2
                block = [block sprintf('\n%%%% ---- integrated from %s ----\n', filesToIntegrate{k}) fileread(src) sprintf('\n')]; %#ok<AGROW>
            else
                warning('Missing integrated helper in backup: %s', src);
            end
        end
        block = [block sprintf('\n%s\n', markerEnd)];
        fid = fopen(fcFile,'a');
        assert(fid > 0, 'Could not open FunctionalConnectivity.m for appending.');
        fwrite(fid, block, 'char');
        fclose(fid);
        fprintf('Re-integrated FC helper block into FunctionalConnectivity.m.\n');
    else
        fprintf('FunctionalConnectivity.m already has integrated helper block.\n');
    end
else
    warning('Could not re-integrate FC helpers because FunctionalConnectivity.m or integrated_helpers backup is missing.');
end

% -------------------------------------------------------------------------
% 3) Conservative safety: restore archived helper files to root.
%    We can remove them later after a proper dependency scan, but this avoids
%    missing-function errors while you test the toolbox.
% -------------------------------------------------------------------------
archDir = fullfile(BAK,'archived_unused_helpers');
archRestored = 0;
if exist(archDir,'dir') == 7
    a = dir(fullfile(archDir,'*.m'));
    for k = 1:numel(a)
        src = fullfile(archDir,a(k).name);
        dst = fullfile(ROOT,a(k).name);
        if exist(dst,'file') ~= 2
            copyfile(src,dst,'f');
            archRestored = archRestored + 1;
        end
    end
end
fprintf('Restored %d archived helper file(s) conservatively.\n', archRestored);

% -------------------------------------------------------------------------
% 4) Re-create deConfUSIon launchers only. Do not rename internal functions.
% -------------------------------------------------------------------------
fid = fopen(fullfile(ROOT,'run_deConfUSIon.m'),'w');
assert(fid > 0, 'Could not write run_deConfUSIon.m');
fprintf(fid, 'function run_deConfUSIon()\n');
fprintf(fid, '%%RUN_DECONFUSION Launch deConfUSIon using the stable fUSI Studio entry point.\n');
fprintf(fid, 'run_fusi_studio;\n');
fprintf(fid, 'end\n');
fclose(fid);

fid = fopen(fullfile(ROOT,'deConfUSIon.m'),'w');
assert(fid > 0, 'Could not write deConfUSIon.m');
fprintf(fid, 'function deConfUSIon()\n');
fprintf(fid, '%%DECONFUSION Launch deConfUSIon.\n');
fprintf(fid, 'run_deConfUSIon;\n');
fprintf(fid, 'end\n');
fclose(fid);

addpath(ROOT);
rehash;
clear functions;

fprintf('\nREPAIR DONE.\n');
fprintf('Now run this:\n  deConfUSIon\n\n');
fprintf('Do NOT rerun the previous deConfUSIon_cleanup_patch.m.\n');
