% deConfUSIon cleanup + safe HUMoR rename patch
% Generated for the current HUMOR-Analysis-Tool structure.
% What it does:
%   1) Creates ROOT\backups\deConfUSIon_cleanup_YYYYMMDD_HHMMSS.
%   2) Appends small FC helper files into FunctionalConnectivity.m as local subfunctions.
%   3) Moves only integrated/unused helper files into the backup subfolder, never deletes them.
%   4) Renames visible HUMoR text in comments and user-facing strings to deConfUSIon,
%      while leaving HUMOR_* function names and HUMOR_fullDisplayName fields unchanged.
%   5) Adds deConfUSIon.m and run_deConfUSIon.m launchers that call run_fusi_studio.
%
% Run from MATLAB Command Window, or edit ROOT below and press Run.

clear; clc;
ROOT = 'D:\Github\HUMOR-Analysis-Tool';
if exist(ROOT,'dir') ~= 7
    warning('Default ROOT not found: %s', ROOT);
    ROOT = pwd;
    fprintf('Using current folder instead: %s\n', ROOT);
end
assert(exist(ROOT,'dir') == 7, 'Toolbox root does not exist. Edit ROOT at the top of this script.');

% Safety switches. Leave these as true for the full cleanup, or set archive to false for a minimal first pass.
INTEGRATE_FC_HELPERS = true;
ARCHIVE_UNUSED_PATCH_HELPERS = true;
REBRAND_VISIBLE_TEXT = true;

fcFile = fullfile(ROOT,'FunctionalConnectivity.m');
assert(exist(fcFile,'file') == 2, 'FunctionalConnectivity.m not found in ROOT: %s', ROOT);
assert(exist(fullfile(ROOT,'run_fusi_studio.m'),'file') == 2, 'run_fusi_studio.m not found in ROOT: %s', ROOT);

ts = datestr(now,'yyyymmdd_HHMMSS');
backupDir = fullfile(ROOT,'backups',['deConfUSIon_cleanup_' ts]);
localEnsureDir(backupDir);
logFile = fullfile(backupDir,'cleanup_log.txt');
localLog(logFile, sprintf('deConfUSIon cleanup started: %s', datestr(now)));
localLog(logFile, sprintf('ROOT: %s', ROOT));

filesToIntegrate = {
    'fc_compare_slice_note.m';
    'fc_label_mask_for_slice.m';
    'fc_region_names_from_region_struct.m';
    'fc_slice_filter_text.m';
    'HUMOR_FC_build_slice_bundle.m';
    'HUMOR_FC_force_layout.m';
    'HUMOR_FC_make_slice_roi_result.m';
    'HUMOR_FC_remember_layout.m';
    'HUMOR_FC_slice_keep_indices.m';
    'HUMOR_FC_stepmotor_read_folder.m';
};
filesToArchiveOnly = {
    'HUMOR_FC_compare_slice_note.m';
    'HUMOR_FC_label_mask_for_slice.m';
    'HUMOR_FC_stepmotor_folder_payload.m';
    'fc_find_stepmotor_name_source.m';
    'fc_slice_keep_indices_from_meta.m';
    'HUMOR_full_dataset_name.m';
    'HUMOR_name_needs_deep_repair.m';
    'HUMOR_pcaica_scope_before_compute.m';
    'HUMOR_pcaica_scope_input.m';
    'HUMOR_pcaica_scope_output.m';
    'HUMOR_pcaica_slice_scope_dialog.m';
    'HUMOR_peek_preproc_display_name.m';
    'HUMOR_pickReg2DUnderlayField.m';
    'HUMOR_pretty_dataset_label.m';
    'HUMOR_redirect_imreg_save_file.m';
    'HUMOR_repair_exact_reopen_names.m';
    'HUMOR_repair_ordered_chain_names.m';
    'HUMOR_repair_preproc_display_names.m';
    'HUMOR_repair_processing_chain_names.m';
    'HUMOR_repair_reopened_dataset_names.m';
    'HUMOR_repair_visible_dataset_names.m';
    'HUMOR_short_imreg_save_path.m';
    'HUMOR_style_load_dataset_dropdown.m';
    'HUMOR_big_scm_video_numeric_fonts.m';
};

% Validate the files that must exist before touching anything important.
if INTEGRATE_FC_HELPERS
    missing = {};
    for i = 1:numel(filesToIntegrate)
        p = fullfile(ROOT,filesToIntegrate{i});
        if exist(p,'file') ~= 2
            missing{end+1} = filesToIntegrate{i}; %#ok<SAGROW>
        end
    end
    if ~isempty(missing)
        error('Required helper file(s) missing, so no cleanup was performed: %s', strjoin(missing, ', '));
    end
end

% 1-2) Integrate selected FC-only helper files into FunctionalConnectivity.m and archive originals.
if INTEGRATE_FC_HELPERS
    markerStart = '%% deConfUSIon integrated FunctionalConnectivity helper block START';
    markerEnd   = '%% deConfUSIon integrated FunctionalConnectivity helper block END';
    fcTxt = fileread(fcFile);
    if contains(fcTxt, markerStart)
        localLog(logFile, 'FunctionalConnectivity.m already contains integrated helper block; skipping append.');
    else
        localBackupFile(ROOT, backupDir, fcFile);
        block = sprintf('\n\n%s\n%% These helper functions were formerly separate root-level patch files.\n%% They are now local subfunctions to reduce toolbox clutter while preserving behavior.\n', markerStart);
        for i = 1:numel(filesToIntegrate)
            src = fullfile(ROOT, filesToIntegrate{i});
            block = [block sprintf('\n%%%% ---- integrated from %s ----\n', filesToIntegrate{i}) fileread(src) sprintf('\n')]; %#ok<AGROW>
        end
        block = [block sprintf('\n%s\n', markerEnd)];
        localWriteText(fcFile, [fcTxt block]);
        localLog(logFile, 'Appended integrated helper block to FunctionalConnectivity.m.');
    end

    % 2) Move integrated helper files into backup/integrated_helpers.
    integratedBackup = fullfile(backupDir,'integrated_helpers');
    localEnsureDir(integratedBackup);
    for i = 1:numel(filesToIntegrate)
        src = fullfile(ROOT, filesToIntegrate{i});
        if exist(src,'file') == 2
            dst = fullfile(integratedBackup, filesToIntegrate{i});
            movefile(src, dst, 'f');
            localLog(logFile, sprintf('Moved integrated helper: %s', filesToIntegrate{i}));
        else
            localLog(logFile, sprintf('Integrated helper already absent: %s', filesToIntegrate{i}));
        end
    end

else
    localLog(logFile, 'Skipping FC helper integration because INTEGRATE_FC_HELPERS=false.');
end

% 3) Move clearly unused/duplicate patch helpers into backup/archived_unused_helpers.
if ARCHIVE_UNUSED_PATCH_HELPERS
    unusedBackup = fullfile(backupDir,'archived_unused_helpers');
    localEnsureDir(unusedBackup);
    for i = 1:numel(filesToArchiveOnly)
        src = fullfile(ROOT, filesToArchiveOnly{i});
        if exist(src,'file') == 2
            dst = fullfile(unusedBackup, filesToArchiveOnly{i});
            movefile(src, dst, 'f');
            localLog(logFile, sprintf('Archived unused/duplicate helper: %s', filesToArchiveOnly{i}));
        end
    end

else
    localLog(logFile, 'Skipping unused-helper archive because ARCHIVE_UNUSED_PATCH_HELPERS=false.');
end

% 4) Rename visible branding safely.
if REBRAND_VISIBLE_TEXT
    %    For .m files: only comments and HUMoR/Humor/humor inside quoted strings are changed.
    %    This intentionally avoids changing HUMOR_* identifiers and HUMOR_fullDisplayName MAT fields.
    files = localListFiles(ROOT, {'.m','.md','.txt'});
    allBackupRoot = fullfile(ROOT,'backups');
    for i = 1:numel(files)
        f = files{i};
        if startsWith(f, allBackupRoot), continue; end
        [~,~,ext] = fileparts(f);
        try
            old = fileread(f);
            if strcmpi(ext,'.m')
                new = localBrandMatlab(old);
            else
                new = strrep(old,'HUMoR','deConfUSIon');
                new = strrep(new,'Humor','deConfUSIon');
                new = strrep(new,'humor','deConfUSIon');
                new = strrep(new,'HUMOR','deConfUSIon');
            end
            if ~strcmp(old,new)
                localBackupFile(ROOT, backupDir, f);
                localWriteText(f,new);
                localLog(logFile, sprintf('Updated visible branding: %s', localRelPath(ROOT,f)));
            end
        catch ME
            localLog(logFile, sprintf('WARNING: could not brand-update %s: %s', f, ME.message));
        end
    end

else
    localLog(logFile, 'Skipping visible-text rebranding because REBRAND_VISIBLE_TEXT=false.');
end

% 5) Add neutral deConfUSIon launchers.
launcher1 = fullfile(ROOT,'run_deConfUSIon.m');
launcher1Txt = [ ...
    'function run_deConfUSIon()' newline ...
    '%RUN_DECONFUSION Launch the deConfUSIon fUSI Studio.' newline ...
    '% Compatibility wrapper around the existing run_fusi_studio entry point.' newline ...
    'run_fusi_studio;' newline ...
    'end' newline];
if exist(launcher1,'file') == 2, localBackupFile(ROOT, backupDir, launcher1); end
localWriteText(launcher1, launcher1Txt);
localLog(logFile, 'Wrote run_deConfUSIon.m launcher.');

launcher2 = fullfile(ROOT,'deConfUSIon.m');
launcher2Txt = [ ...
    'function deConfUSIon()' newline ...
    '%DECONFUSION Launch the deConfUSIon fUSI Studio.' newline ...
    'run_deConfUSIon;' newline ...
    'end' newline];
if exist(launcher2,'file') == 2, localBackupFile(ROOT, backupDir, launcher2); end
localWriteText(launcher2, launcher2Txt);
localLog(logFile, 'Wrote deConfUSIon.m launcher.');

rehash;
clear functions;
fprintf('\nDONE. Cleanup finished safely.\n');
fprintf('Backups/log: %s\n', backupDir);
fprintf('Start the toolbox with: deConfUSIon\n\n');
try
    addpath(ROOT);
catch
end

% ---------------- local helper functions ----------------
function localEnsureDir(d)
if exist(d,'dir') ~= 7, mkdir(d); end
end

function localLog(logFile,msg)
fid = fopen(logFile,'a');
if fid > 0
    fprintf(fid,'%s\n',msg);
    fclose(fid);
end
fprintf('%s\n',msg);
end

function localWriteText(f,txt)
fid = fopen(f,'w');
assert(fid > 0, 'Cannot write file: %s', f);
fwrite(fid, txt, 'char');
fclose(fid);
end

function localBackupFile(rootDir, backupDir, srcFile)
rel = localRelPath(rootDir, srcFile);
dst = fullfile(backupDir,'originals',rel);
[p,~,~] = fileparts(dst);
localEnsureDir(p);
if exist(dst,'file') ~= 2
    copyfile(srcFile,dst,'f');
end
end

function rel = localRelPath(rootDir, f)
rootDir = char(rootDir); f = char(f);
if length(f) >= length(rootDir) && strcmpi(f(1:length(rootDir)), rootDir)
    rel = f(length(rootDir)+1:end);
    if startsWith(rel, filesep), rel = rel(2:end); end
else
    [~,nm,ex] = fileparts(f); rel = [nm ex];
end
end

function files = localListFiles(rootDir, exts)
files = {};
d = dir(rootDir);
for k = 1:numel(d)
    nm = d(k).name;
    if strcmp(nm,'.') || strcmp(nm,'..'), continue; end
    if strcmpi(nm,'.git'), continue; end
    p = fullfile(rootDir,nm);
    if d(k).isdir
        sub = localListFiles(p, exts);
        files = [files sub]; %#ok<AGROW>
    else
        [~,~,e] = fileparts(nm);
        if any(strcmpi(e,exts))
            files{end+1} = p; %#ok<AGROW>
        end
    end
end
end

function out = localBrandMatlab(in)
% Safe branding for MATLAB files:
% - Replace HUMOR/HUMoR in comments.
% - Replace only mixed/lowercase HUMoR/Humor/humor inside strings.
% - Do not replace all-caps HUMOR inside strings to preserve internal keys/fields.
parts = regexp(in, '\r\n|\n|\r', 'split');
seps = regexp(in, '\r\n|\n|\r', 'match');
out = '';
for ii = 1:numel(parts)
    out = [out localBrandLine(parts{ii})]; %#ok<AGROW>
    if ii <= numel(seps), out = [out seps{ii}]; end %#ok<AGROW>
end
end

function lineOut = localBrandLine(lineIn)
lineOut = '';
i = 1; n = length(lineIn);
while i <= n
    c = lineIn(i);
    if c == ''''
        % Copy opening quote.
        lineOut = [lineOut c]; %#ok<AGROW>
        i = i + 1;
        seg = '';
        while i <= n
            if lineIn(i) == ''''
                if i < n && lineIn(i+1) == ''''
                    seg = [seg '''''']; %#ok<AGROW>
                    i = i + 2;
                else
                    seg = strrep(seg,'HUMoR','deConfUSIon');
                    seg = strrep(seg,'Humor','deConfUSIon');
                    seg = strrep(seg,'humor','deConfUSIon');
                    lineOut = [lineOut seg '''']; %#ok<AGROW>
                    i = i + 1;
                    break;
                end
            else
                seg = [seg lineIn(i)]; %#ok<AGROW>
                i = i + 1;
            end
        end
        if i > n && ~isempty(seg)
            seg = strrep(seg,'HUMoR','deConfUSIon');
            seg = strrep(seg,'Humor','deConfUSIon');
            seg = strrep(seg,'humor','deConfUSIon');
            lineOut = [lineOut seg]; %#ok<AGROW>
        end
    elseif c == '%'
        comment = lineIn(i:end);
        comment = strrep(comment,'HUMoR','deConfUSIon');
        comment = strrep(comment,'Humor','deConfUSIon');
        comment = strrep(comment,'humor','deConfUSIon');
        comment = strrep(comment,'HUMOR','deConfUSIon');
        lineOut = [lineOut comment]; %#ok<AGROW>
        return;
    else
        lineOut = [lineOut c]; %#ok<AGROW>
        i = i + 1;
    end
end
end
