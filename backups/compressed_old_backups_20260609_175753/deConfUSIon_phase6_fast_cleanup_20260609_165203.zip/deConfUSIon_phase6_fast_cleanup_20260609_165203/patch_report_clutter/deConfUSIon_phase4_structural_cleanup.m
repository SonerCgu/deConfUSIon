%% deConfUSIon PHASE 4 structural cleanup - safe + reversible
% Goals:
%   1) integrate small single-caller helper .m files into their main files
%   2) archive root-level clutter, shadowed duplicates, old reports, misspelled bakcups
%   3) remove empty backup/report folders
%   4) write a post-cleanup inventory
%
% Safety:
%   - no permanent deletion of files, except empty directories via rmdir
%   - every edited target file is backed up first
%   - helpers are moved to backups only after integration succeeds
%   - files are integrated only if no other active caller uses them

root = 'D:\Github\HUMOR-Analysis-Tool';
root = regexprep(root,'[\\/]+$','');

stamp = datestr(now,'yyyymmdd_HHMMSS');
archiveRoot = fullfile(root,'backups',['deConfUSIon_phase4_structural_cleanup_' stamp]);
editBackupDir = fullfile(archiveRoot,'before_edit');
integratedDir = fullfile(archiveRoot,'integrated_helpers');
clutterDir = fullfile(archiveRoot,'archived_clutter');
mkdir(archiveRoot);
mkdir(editBackupDir);
mkdir(integratedDir);
mkdir(clutterDir);

fprintf('\n=== deConfUSIon PHASE 4 structural cleanup ===\n');
fprintf('ROOT   : %s\n', root);
fprintf('ARCHIVE: %s\n\n', archiveRoot);

logFile = fullfile(archiveRoot,'phase4_cleanup_log.tsv');
fidLog = fopen(logFile,'w');
fprintf(fidLog,'action\titem\tstatus\tdetails\n');

%% ------------------------------------------------------------------------
% Remove backup/report folders from MATLAB path so old files cannot shadow new ones
%% ------------------------------------------------------------------------
badPathRoots = {fullfile(root,'backups'), fullfile(root,'bakcups'), fullfile(root,'cleanup_reports')};
for bi = 1:numel(badPathRoots)
    if exist(badPathRoots{bi},'dir') == 7
        gp = regexp(genpath(badPathRoots{bi}), pathsep, 'split');
        for gi = 1:numel(gp)
            if isempty(gp{gi}), continue; end
            try, rmpath(gp{gi}); catch, end
        end
    end
end
addpath(root,'-begin');
atlasTools = fullfile(root,'atlas_tools');
if exist(atlasTools,'dir') == 7
    addpath(atlasTools,'-begin');
end

%% ------------------------------------------------------------------------
% Snapshot active .m files before cleanup
%% ------------------------------------------------------------------------
activeFiles = {};
rawDirs = regexp(genpath(root), pathsep, 'split');
for di = 1:numel(rawDirs)
    d = rawDirs{di};
    if isempty(d), continue; end
    dl = lower(d);

    skip = false;
    skip = skip || ~isempty(strfind(dl,[filesep 'backups']));
    skip = skip || ~isempty(strfind(dl,[filesep 'bakcups']));
    skip = skip || ~isempty(strfind(dl,[filesep 'cleanup_reports']));
    skip = skip || ~isempty(strfind(dl,[filesep 'archived']));
    skip = skip || ~isempty(strfind(dl,[filesep '.git']));
    skip = skip || ~isempty(strfind(dl,[filesep '__macosx']));
    if skip, continue; end

    ff = dir(fullfile(d,'*.m'));
    for k = 1:numel(ff)
        activeFiles{end+1} = fullfile(d,ff(k).name); %#ok<SAGROW>
    end
end
nBefore = numel(activeFiles);
fprintf('Active .m files before cleanup: %d\n', nBefore);
fprintf(fidLog,'INFO\tactive_m_before\t%d\t\n', nBefore);

%% ------------------------------------------------------------------------
% 1) Integrate small single-caller helpers into main files
%% ------------------------------------------------------------------------
integratePairs = { ...
    'fc_compare_slice_note.m',                    'FunctionalConnectivity.m'; ...
    'fc_label_mask_for_slice.m',                  'FunctionalConnectivity.m'; ...
    'fc_region_names_from_region_struct.m',       'FunctionalConnectivity.m'; ...
    'fc_slice_filter_text.m',                     'FunctionalConnectivity.m'; ...
    'deConfUSIon_FC_build_slice_bundle.m',        'FunctionalConnectivity.m'; ...
    'deConfUSIon_FC_make_slice_roi_result.m',     'FunctionalConnectivity.m'; ...
    'deConfUSIon_FC_slice_keep_indices.m',        'FunctionalConnectivity.m'; ...
    'deConfUSIon_FC_stepmotor_read_folder.m',     'FunctionalConnectivity.m'; ...
    'deConfUSIon_style_rejected_qc_axis.m',       'qc_fusi.m'; ...
    'deConfUSIon_force_png_white_background.m',   'qc_fusi.m' ...
};

% Source helper basenames in this integration batch.
batchBases = {};
for ip = 1:size(integratePairs,1)
    [~,bb,~] = fileparts(integratePairs{ip,1});
    batchBases{end+1} = bb; %#ok<SAGROW>
end

% For conflict checking within each target, keep track of newly appended function names.
fprintf('\nIntegrating small helpers into main files...\n');

for ip = 1:size(integratePairs,1)

    helperRel = integratePairs{ip,1};
    targetRel = integratePairs{ip,2};

    helperPath = fullfile(root,helperRel);
    targetPath = fullfile(root,targetRel);

    if exist(helperPath,'file') ~= 2
        fprintf('  SKIP missing helper: %s\n', helperRel);
        fprintf(fidLog,'INTEGRATE\t%s\tSKIP_MISSING_HELPER\t%s\n', helperRel, targetRel);
        continue;
    end

    if exist(targetPath,'file') ~= 2
        fprintf('  SKIP missing target: %s\n', targetRel);
        fprintf(fidLog,'INTEGRATE\t%s\tSKIP_MISSING_TARGET\t%s\n', helperRel, targetRel);
        continue;
    end

    [~,helperBase,~] = fileparts(helperPath);

    % Check active references outside target and outside this integration batch.
    token = ['(?<![A-Za-z0-9_])' regexptranslate('escape',helperBase) '(?![A-Za-z0-9_])'];
    externalRefs = 0;
    externalWhere = {};

    for fi = 1:numel(activeFiles)
        f = activeFiles{fi};
        [~,fb,~] = fileparts(f);

        % Ignore the helper itself, target file, and other helper files in this batch.
        if strcmpi(f,helperPath), continue; end
        if strcmpi(f,targetPath), continue; end
        if any(strcmp(fb,batchBases)), continue; end

        try
            t = fileread(f);
        catch
            t = '';
        end

        lines = regexp(t, '\r\n|\n|\r', 'split');
        for li = 1:numel(lines)
            lines{li} = regexprep(lines{li}, '%.*$', '');
        end
        cleanText = sprintf('%s\n', lines{:});
        c = numel(regexp(cleanText, token, 'match'));

        if c > 0
            externalRefs = externalRefs + c;
            externalWhere{end+1} = sprintf('%s:%d',strrep(f,[root filesep],''),c); %#ok<SAGROW>
        end
    end

    if externalRefs > 0
        fprintf('  KEEP external callers exist: %s refs=%d\n', helperRel, externalRefs);
        fprintf(fidLog,'INTEGRATE\t%s\tSKIP_EXTERNAL_REFS\t%s\n', helperRel, strjoin(externalWhere,'; '));
        continue;
    end

    helperTxt = fileread(helperPath);
    targetTxt = fileread(targetPath);

    % Function names declared inside helper file.
    helperFuncs = regexp(helperTxt, ...
        '^\s*function\s+(?:\[[^\]]*\]\s*=\s*|[A-Za-z]\w*\s*=\s*)?([A-Za-z]\w*)', ...
        'tokens','lineanchors');

    helperFuncNames = {};
    for hf = 1:numel(helperFuncs)
        helperFuncNames{end+1} = helperFuncs{hf}{1}; %#ok<SAGROW>
    end

    % Function names already declared inside target file.
    targetFuncs = regexp(targetTxt, ...
        '^\s*function\s+(?:\[[^\]]*\]\s*=\s*|[A-Za-z]\w*\s*=\s*)?([A-Za-z]\w*)', ...
        'tokens','lineanchors');

    targetFuncNames = {};
    for tf = 1:numel(targetFuncs)
        targetFuncNames{end+1} = targetFuncs{tf}{1}; %#ok<SAGROW>
    end

    conflict = {};
    for hf = 1:numel(helperFuncNames)
        if any(strcmp(helperFuncNames{hf}, targetFuncNames))
            conflict{end+1} = helperFuncNames{hf}; %#ok<SAGROW>
        end
    end

    if ~isempty(conflict)
        fprintf('  KEEP conflict in target: %s | %s\n', helperRel, strjoin(conflict,', '));
        fprintf(fidLog,'INTEGRATE\t%s\tSKIP_FUNCTION_NAME_CONFLICT\t%s\n', helperRel, strjoin(conflict,', '));
        continue;
    end

    % Backup target once per helper operation.
    safeTargetName = strrep(targetRel,filesep,'__');
    backupTarget = fullfile(editBackupDir,[safeTargetName '_before_' helperBase '.m']);
    try, copyfile(targetPath, backupTarget); catch, end

    % Append helper as local functions.
    banner = sprintf('\n\n%%%% ---- Integrated deConfUSIon helper from %s on %s ----\n', helperRel, datestr(now));
    try
        fidW = fopen(targetPath,'a');
        fwrite(fidW,banner);
        fwrite(fidW,helperTxt);
        if isempty(helperTxt) || helperTxt(end) ~= sprintf('\n')
            fwrite(fidW,sprintf('\n'));
        end
        fclose(fidW);

        dst = fullfile(integratedDir,helperRel);
        dstDir = fileparts(dst);
        if exist(dstDir,'dir') ~= 7, mkdir(dstDir); end
        movefile(helperPath,dst);

        fprintf('  INTEGRATED: %s -> %s\n', helperRel, targetRel);
        fprintf(fidLog,'INTEGRATE\t%s\tMOVED_TO_TARGET\t%s\n', helperRel, targetRel);
    catch ME
        try, if exist('fidW','var') && fidW > 0, fclose(fidW); end, catch, end
        fprintf('  FAILED integration: %s | %s\n', helperRel, ME.message);
        fprintf(fidLog,'INTEGRATE\t%s\tFAILED\t%s\n', helperRel, ME.message);

        % restore target from backup if possible
        try
            if exist(backupTarget,'file') == 2
                copyfile(backupTarget,targetPath);
            end
        catch
        end
    end
end

%% ------------------------------------------------------------------------
% 2) Move manual/zero-ref atlas utilities from root into atlas_tools or archive
%% ------------------------------------------------------------------------
fprintf('\nMoving manual atlas utilities out of root when safe...\n');

manualAtlasMoves = { ...
    'save_correct_colors.m',              fullfile('atlas_tools','save_correct_colors.m'); ...
    'deConfUSIon_reorder_FC_by_list.m',   fullfile('atlas_tools','deConfUSIon_reorder_FC_by_list.m') ...
};

for mi = 1:size(manualAtlasMoves,1)
    srcRel = manualAtlasMoves{mi,1};
    dstRel = manualAtlasMoves{mi,2};
    src = fullfile(root,srcRel);
    dst = fullfile(root,dstRel);

    if exist(src,'file') ~= 2
        fprintf('  SKIP missing/manual already moved: %s\n', srcRel);
        fprintf(fidLog,'MOVE_MANUAL_ATLAS\t%s\tMISSING\t%s\n', srcRel, dstRel);
        continue;
    end

    [~,base,~] = fileparts(srcRel);
    token = ['(?<![A-Za-z0-9_])' regexptranslate('escape',base) '(?![A-Za-z0-9_])'];

    refOutsideSelf = 0;
    where = {};
    for fi = 1:numel(activeFiles)
        f = activeFiles{fi};
        if strcmpi(f,src), continue; end
        try, t = fileread(f); catch, t = ''; end
        lines = regexp(t, '\r\n|\n|\r', 'split');
        for li = 1:numel(lines), lines{li} = regexprep(lines{li}, '%.*$', ''); end
        cleanText = sprintf('%s\n',lines{:});
        c = numel(regexp(cleanText,token,'match'));
        if c > 0
            refOutsideSelf = refOutsideSelf + c;
            where{end+1} = sprintf('%s:%d',strrep(f,[root filesep],''),c); %#ok<SAGROW>
        end
    end

    if refOutsideSelf > 0
        fprintf('  KEEP root manual utility still referenced: %s refs=%d\n', srcRel, refOutsideSelf);
        fprintf(fidLog,'MOVE_MANUAL_ATLAS\t%s\tKEEP_REFERENCED\t%s\n', srcRel, strjoin(where,'; '));
        continue;
    end

    dstDir = fileparts(dst);
    if exist(dstDir,'dir') ~= 7, mkdir(dstDir); end

    if exist(dst,'file') == 2
        backupExisting = fullfile(clutterDir,['existing_' strrep(dstRel,filesep,'__')]);
        try, movefile(dst,backupExisting); catch, end
    end

    try
        movefile(src,dst);
        fprintf('  MOVED to atlas_tools: %s\n', srcRel);
        fprintf(fidLog,'MOVE_MANUAL_ATLAS\t%s\tMOVED\t%s\n', srcRel, dstRel);
    catch ME
        fprintf('  FAILED moving manual atlas utility: %s | %s\n', srcRel, ME.message);
        fprintf(fidLog,'MOVE_MANUAL_ATLAS\t%s\tFAILED\t%s\n', srcRel, ME.message);
    end
end

%% ------------------------------------------------------------------------
% 3) Archive old HUMOR legacy wrappers if no active non-HUMOR references remain
%% ------------------------------------------------------------------------
fprintf('\nArchiving old HUMOR legacy wrappers if still unreferenced...\n');

legacyCandidates = { ...
    'HUMOR_canonical_dataset_label.m', ...
    'HUMOR_compact_chain_name.m', ...
    'HUMOR_display_name_from_sources.m', ...
    'HUMOR_ordered_chain_label.m' ...
};

for li = 1:numel(legacyCandidates)
    rel = legacyCandidates{li};
    src = fullfile(root,rel);

    if exist(src,'file') ~= 2
        fprintf('  SKIP missing legacy: %s\n', rel);
        fprintf(fidLog,'ARCHIVE_LEGACY_HUMOR\t%s\tMISSING\t\n', rel);
        continue;
    end

    [~,base,~] = fileparts(rel);
    token = ['(?<![A-Za-z0-9_])' regexptranslate('escape',base) '(?![A-Za-z0-9_])'];

    refCount = 0;
    refWhere = {};
    for fi = 1:numel(activeFiles)
        f = activeFiles{fi};
        [~,fb,~] = fileparts(f);

        % Ignore the legacy files themselves and this old legacy group.
        if strcmpi(f,src), continue; end
        if any(strcmp([fb '.m'],legacyCandidates)), continue; end

        try, t = fileread(f); catch, t = ''; end
        lines = regexp(t, '\r\n|\n|\r', 'split');
        for tj = 1:numel(lines), lines{tj} = regexprep(lines{tj}, '%.*$', ''); end
        cleanText = sprintf('%s\n',lines{:});

        c = numel(regexp(cleanText,token,'match'));
        if c > 0
            refCount = refCount + c;
            refWhere{end+1} = sprintf('%s:%d',strrep(f,[root filesep],''),c); %#ok<SAGROW>
        end
    end

    if refCount > 0
        fprintf('  KEEP legacy still referenced externally: %s refs=%d\n', rel, refCount);
        fprintf(fidLog,'ARCHIVE_LEGACY_HUMOR\t%s\tKEEP_REFERENCED\t%s\n', rel, strjoin(refWhere,'; '));
        continue;
    end

    dst = fullfile(clutterDir,'legacy_HUMOR_wrappers',rel);
    dstDir = fileparts(dst);
    if exist(dstDir,'dir') ~= 7, mkdir(dstDir); end

    try
        movefile(src,dst);
        fprintf('  ARCHIVED legacy wrapper: %s\n', rel);
        fprintf(fidLog,'ARCHIVE_LEGACY_HUMOR\t%s\tMOVED\t%s\n', rel, dst);
    catch ME
        fprintf('  FAILED archiving legacy wrapper: %s | %s\n', rel, ME.message);
        fprintf(fidLog,'ARCHIVE_LEGACY_HUMOR\t%s\tFAILED\t%s\n', rel, ME.message);
    end
end

%% ------------------------------------------------------------------------
% 4) Archive root/manual clutter that is not part of active Studio/FC workflow
%% ------------------------------------------------------------------------
fprintf('\nArchiving root clutter/manual source archives if present...\n');

clutterMoves = { ...
    fullfile('atlas_tools','matlab_functions.rar'), ...
    'vfUSI_StimBox_TTL_EACH_FRAME_OR_TRIGGER_ACCESSORIES_COMMAND.m' ...
};

for ci = 1:numel(clutterMoves)
    rel = clutterMoves{ci};
    src = fullfile(root,rel);

    if exist(src,'file') ~= 2
        fprintf('  SKIP missing clutter: %s\n', rel);
        fprintf(fidLog,'ARCHIVE_CLUTTER\t%s\tMISSING\t\n', rel);
        continue;
    end

    [~,base,~] = fileparts(rel);
    token = ['(?<![A-Za-z0-9_])' regexptranslate('escape',base) '(?![A-Za-z0-9_])'];

    refCount = 0;
    where = {};
    for fi = 1:numel(activeFiles)
        f = activeFiles{fi};
        if strcmpi(f,src), continue; end
        try, t = fileread(f); catch, t = ''; end
        lines = regexp(t, '\r\n|\n|\r', 'split');
        for lj = 1:numel(lines), lines{lj} = regexprep(lines{lj}, '%.*$', ''); end
        cleanText = sprintf('%s\n',lines{:});
        c = numel(regexp(cleanText,token,'match'));
        if c > 0
            refCount = refCount + c;
            where{end+1} = sprintf('%s:%d',strrep(f,[root filesep],''),c); %#ok<SAGROW>
        end
    end

    if refCount > 0
        fprintf('  KEEP referenced clutter/manual file: %s refs=%d\n', rel, refCount);
        fprintf(fidLog,'ARCHIVE_CLUTTER\t%s\tKEEP_REFERENCED\t%s\n', rel, strjoin(where,'; '));
        continue;
    end

    dst = fullfile(clutterDir,rel);
    dstDir = fileparts(dst);
    if exist(dstDir,'dir') ~= 7, mkdir(dstDir); end

    try
        movefile(src,dst);
        fprintf('  ARCHIVED clutter/manual file: %s\n', rel);
        fprintf(fidLog,'ARCHIVE_CLUTTER\t%s\tMOVED\t%s\n', rel, dst);
    catch ME
        fprintf('  FAILED archiving clutter file: %s | %s\n', rel, ME.message);
        fprintf(fidLog,'ARCHIVE_CLUTTER\t%s\tFAILED\t%s\n', rel, ME.message);
    end
end

%% ------------------------------------------------------------------------
% 5) Archive old cleanup_reports and misspelled bakcups folder
%% ------------------------------------------------------------------------
fprintf('\nArchiving old cleanup reports and misspelled bakcups folder...\n');

folderMoves = { ...
    'cleanup_reports', 'old_cleanup_reports'; ...
    'bakcups',         'old_misspelled_bakcups' ...
};

for fm = 1:size(folderMoves,1)
    srcRel = folderMoves{fm,1};
    dstRel = folderMoves{fm,2};
    src = fullfile(root,srcRel);

    if exist(src,'dir') ~= 7
        fprintf('  SKIP folder missing: %s\n', srcRel);
        fprintf(fidLog,'ARCHIVE_FOLDER\t%s\tMISSING\t\n', srcRel);
        continue;
    end

    dst = fullfile(archiveRoot,dstRel);
    if exist(dst,'dir') == 7
        dst = [dst '_' datestr(now,'HHMMSSFFF')];
    end

    try
        movefile(src,dst);
        fprintf('  ARCHIVED folder: %s\n', srcRel);
        fprintf(fidLog,'ARCHIVE_FOLDER\t%s\tMOVED\t%s\n', srcRel, dst);
    catch ME
        fprintf('  FAILED archiving folder: %s | %s\n', srcRel, ME.message);
        fprintf(fidLog,'ARCHIVE_FOLDER\t%s\tFAILED\t%s\n', srcRel, ME.message);
    end
end

%% ------------------------------------------------------------------------
% 6) Remove empty directories under backups only
%% ------------------------------------------------------------------------
fprintf('\nRemoving empty backup/report directories only...\n');

for pass = 1:5
    dirsToCheck = {};
    if exist(fullfile(root,'backups'),'dir') == 7
        allDirs = regexp(genpath(fullfile(root,'backups')), pathsep, 'split');
        for di = 1:numel(allDirs)
            if ~isempty(allDirs{di})
                dirsToCheck{end+1} = allDirs{di}; %#ok<SAGROW>
            end
        end
    end

    % deepest dirs first
    [~,ord] = sort(cellfun(@numel,dirsToCheck),'descend');
    dirsToCheck = dirsToCheck(ord);

    for di = 1:numel(dirsToCheck)
        d = dirsToCheck{di};
        if strcmpi(d,fullfile(root,'backups')), continue; end
        if exist(d,'dir') ~= 7, continue; end
        content = dir(d);
        content = content(~ismember({content.name},{'.','..'}));
        if isempty(content)
            try
                rmdir(d);
                fprintf('  REMOVED empty dir: %s\n', strrep(d,[root filesep],''));
                fprintf(fidLog,'REMOVE_EMPTY_DIR\t%s\tREMOVED\t\n', strrep(d,[root filesep],''));
            catch
            end
        end
    end
end

%% ------------------------------------------------------------------------
% 7) Final path cleanup and inventory
%% ------------------------------------------------------------------------
% Remove backup/report folders from path again
badPathRoots = {fullfile(root,'backups'), fullfile(root,'bakcups'), fullfile(root,'cleanup_reports')};
for bi = 1:numel(badPathRoots)
    if exist(badPathRoots{bi},'dir') == 7
        gp = regexp(genpath(badPathRoots{bi}), pathsep, 'split');
        for gi = 1:numel(gp)
            if isempty(gp{gi}), continue; end
            try, rmpath(gp{gi}); catch, end
        end
    end
end
addpath(root,'-begin');
atlasTools = fullfile(root,'atlas_tools');
if exist(atlasTools,'dir') == 7
    addpath(atlasTools,'-begin');
end

rehash;
clear functions;

% Final active file inventory
activeAfter = {};
rawDirs = regexp(genpath(root), pathsep, 'split');
for di = 1:numel(rawDirs)
    d = rawDirs{di};
    if isempty(d), continue; end
    dl = lower(d);

    skip = false;
    skip = skip || ~isempty(strfind(dl,[filesep 'backups']));
    skip = skip || ~isempty(strfind(dl,[filesep 'bakcups']));
    skip = skip || ~isempty(strfind(dl,[filesep 'cleanup_reports']));
    skip = skip || ~isempty(strfind(dl,[filesep 'archived']));
    skip = skip || ~isempty(strfind(dl,[filesep '.git']));
    skip = skip || ~isempty(strfind(dl,[filesep '__macosx']));
    if skip, continue; end

    ff = dir(fullfile(d,'*.m'));
    for k = 1:numel(ff)
        activeAfter{end+1} = fullfile(d,ff(k).name); %#ok<SAGROW>
    end
end

nAfter = numel(activeAfter);
fprintf(fidLog,'INFO\tactive_m_after\t%d\t\n', nAfter);

inventoryFile = fullfile(archiveRoot,'post_phase4_active_m_inventory.tsv');
fidInv = fopen(inventoryFile,'w');
fprintf(fidInv,'file\tlines\tbytes\n');

for fi = 1:numel(activeAfter)
    f = activeAfter{fi};
    try
        txt = fileread(f);
        nLines = numel(regexp(txt,'\r\n|\n|\r','split'));
    catch
        txt = '';
        nLines = 0;
    end
    info = dir(f);
    fprintf(fidInv,'%s\t%d\t%d\n', strrep(f,[root filesep],''), nLines, info.bytes);
end
fclose(fidInv);

fclose(fidLog);

fprintf('\nDONE. Phase 4 cleanup complete.\n');
fprintf('Active .m files before: %d\n', nBefore);
fprintf('Active .m files after : %d\n', nAfter);
fprintf('Reduced by            : %d files\n', nBefore - nAfter);
fprintf('\nArchive/log folder:\n%s\n', archiveRoot);
fprintf('Inventory:\n%s\n', inventoryFile);

fprintf('\nNow test:\n');
fprintf('  which deConfUSIon\n');
fprintf('  which readFileList\n');
fprintf('  which save_correct_colors\n');
fprintf('  which fc_compare_slice_note\n');
fprintf('  which deConfUSIon_FC_make_slice_roi_result\n');
fprintf('  deConfUSIon\n');
