%% deConfUSIon PHASE 7 - final polish cleanup and remaining HUMOR rename
% Goal:
%   - Archive old phase/patch scripts and zero-reference leftovers.
%   - Rename any remaining active HUMOR_/HUMoR_ root helpers to deConfUSIon_*.
%   - Integrate only tiny one-owner helper files that remain after Phase 6.
%   - Keep shared helpers, callbacks, layout/timer helpers, atlas tools, and main modules.
%
% Usage:
%   run('D:\Github\HUMOR-Analysis-Tool\deConfUSIon_phase7_final_polish_cleanup.m')
%
% Safety:
%   - No permanent deletion.
%   - Backups are created before every edit.
%   - Old files are moved into backups only after references are rewritten.
%   - Dynamic reference checks are performed immediately before archiving.

clearvars -except root
clc

if exist('root','var') ~= 1 || isempty(root)
    root = 'D:\Github\HUMOR-Analysis-Tool';
end
root = char(regexprep(root,'[\\/]+$',''));

if exist(root,'dir') ~= 7
    error('Toolbox root not found: %s', root);
end

stamp = datestr(now,'yyyymmdd_HHMMSS');
archiveRoot = fullfile(root,'backups',['deConfUSIon_phase7_final_polish_' stamp]);
beforeEditDir = fullfile(archiveRoot,'before_edit');
patchClutterDir = fullfile(archiveRoot,'patch_script_clutter');
zeroRefDir = fullfile(archiveRoot,'zero_reference_leftovers');
renamedHumorDir = fullfile(archiveRoot,'renamed_legacy_HUMOR_helpers');
integratedDir = fullfile(archiveRoot,'integrated_tiny_helpers');
mkdir(archiveRoot);
mkdir(beforeEditDir);
mkdir(patchClutterDir);
mkdir(zeroRefDir);
mkdir(renamedHumorDir);
mkdir(integratedDir);

diaryFile = fullfile(archiveRoot,'phase7_console_log.txt');
try, diary(diaryFile); catch, end

fprintf('\n=== deConfUSIon PHASE 7: final polish cleanup ===\n');
fprintf('ROOT   : %s\n', root);
fprintf('ARCHIVE: %s\n\n', archiveRoot);

logFile = fullfile(archiveRoot,'phase7_action_log.tsv');
fidLog = fopen(logFile,'w');
fprintf(fidLog,'action\tstatus\tsource\ttarget\tdetails\n');

%% Keep backups/reports off path
removeBackupReportPaths(root);
addpath(root,'-begin');

%% 1) Archive previous phase/patch scripts from root
fprintf('\n--- 1) Archiving previous patch scripts from root ---\n');

rootListing = dir(root);
for i = 1:numel(rootListing)
    if rootListing(i).isdir, continue; end
    nm = rootListing(i).name;

    if strcmpi(nm,'deConfUSIon_phase7_final_polish_cleanup.m')
        continue;
    end

    isPatch = false;
    isPatch = isPatch || ~isempty(regexpi(nm,'^deConfUSIon_phase[0-6].*\.m$','once'));
    isPatch = isPatch || ~isempty(regexpi(nm,'^deConfUSIon_.*(cleanup|hotfix|repair|finalize|audit).*\.m$','once'));

    if isPatch
        moveWithArchive(fullfile(root,nm), fullfile(patchClutterDir,nm), fidLog, 'ARCHIVE_PATCH_SCRIPT');
    end
end

%% 2) Collect active .m files and rename remaining HUMOR/HUMoR root helpers
fprintf('\n--- 2) Renaming remaining HUMOR/HUMoR root helpers ---\n');

[mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);
fprintf('Active .m files before Phase 7: %d\n', numel(mFiles));

% Find root-level HUMOR/HUMoR files.
h = [dir(fullfile(root,'HUMOR*.m')); dir(fullfile(root,'HUMoR*.m'))];

renameOld = {};
renameNew = {};
renameSrc = {};

for i = 1:numel(h)
    [~,oldBase,~] = fileparts(h(i).name);

    % Keep nothing HUMOR-named in root unless it is impossible/risky.
    if strncmp(oldBase,'HUMOR_',6)
        suffix = oldBase(7:end);
    elseif strncmp(oldBase,'HUMoR_',6)
        suffix = oldBase(7:end);
    else
        suffix = regexprep(oldBase,'^HUMOR','');
        suffix = regexprep(suffix,'^HUMoR','');
        suffix = regexprep(suffix,'^_','');
    end

    if isempty(suffix)
        continue;
    end

    newBase = ['deConfUSIon_' suffix];

    % If the deConfUSIon equivalent already exists, only rewrite refs and archive old.
    renameOld{end+1} = oldBase; %#ok<AGROW>
    renameNew{end+1} = newBase; %#ok<AGROW>
    renameSrc{end+1} = fullfile(root,h(i).name); %#ok<AGROW>
end

if isempty(renameOld)
    fprintf('No remaining root HUMOR/HUMoR helpers found.\n');
else
    fprintf('Remaining HUMOR/HUMoR helpers found: %d\n', numel(renameOld));

    % Create missing deConfUSIon copies.
    for i = 1:numel(renameOld)
        oldBase = renameOld{i};
        newBase = renameNew{i};
        src = renameSrc{i};
        dst = fullfile(root,[newBase '.m']);

        if exist(src,'file') ~= 2
            continue;
        end

        if exist(dst,'file') ~= 2
            try
                txt = fileread(src);
                for j = 1:numel(renameOld)
                    pat = ['(?<![A-Za-z0-9_])' regexptranslate('escape',renameOld{j}) '(?![A-Za-z0-9_])'];
                    txt = regexprep(txt, pat, renameNew{j});
                end
                writeTextFile(dst, txt);
                fprintf('CREATED renamed helper: %s.m\n', newBase);
                fprintf(fidLog,'RENAME_HUMOR\tCREATED_NEW\t%s\t%s\t\n', src, dst);
            catch ME
                fprintf('FAILED creating %s.m from %s.m: %s\n', newBase, oldBase, ME.message);
                fprintf(fidLog,'RENAME_HUMOR\tFAILED_CREATE\t%s\t%s\t%s\n', src, dst, ME.message);
            end
        else
            fprintf('Renamed helper already exists: %s.m\n', newBase);
            fprintf(fidLog,'RENAME_HUMOR\tTARGET_ALREADY_EXISTS\t%s\t%s\t\n', src, dst);
        end
    end

    % Refresh active files after creating new names.
    [mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);

    % Rewrite all active files except old HUMOR files.
    edited = 0;
    for fi = 1:numel(mFiles)
        f = mFiles{fi};
        [~,base,~] = fileparts(f);

        if any(strcmp(base, renameOld))
            continue;
        end

        try
            txt = fileread(f);
        catch
            continue;
        end
        oldTxt = txt;

        for j = 1:numel(renameOld)
            pat = ['(?<![A-Za-z0-9_])' regexptranslate('escape',renameOld{j}) '(?![A-Za-z0-9_])'];
            txt = regexprep(txt, pat, renameNew{j});
        end

        if ~strcmp(txt, oldTxt)
            rel = relativePath(f, root);
            backupFile = fullfile(beforeEditDir, strrep(rel,filesep,'__'));
            if exist(backupFile,'file') ~= 2
                copyfile(f, backupFile);
            end
            writeTextFile(f, txt);
            edited = edited + 1;
            fprintf('PATCHED old HUMOR references in: %s\n', rel);
            fprintf(fidLog,'REWRITE_HUMOR_REFS\tPATCHED\t%s\t\t\n', rel);
        end
    end
    fprintf('Files patched for remaining HUMOR refs: %d\n', edited);

    % Archive old HUMOR files if zero remaining active refs.
    [mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);
    textsNoComments = readNoCommentTexts(mFiles);

    for i = 1:numel(renameOld)
        oldBase = renameOld{i};
        src = renameSrc{i};

        if exist(src,'file') ~= 2
            continue;
        end

        refCount = countRefsToBase(oldBase, src, mFiles, textsNoComments);

        if refCount == 0
            moveWithArchive(src, fullfile(renamedHumorDir,[oldBase '.m']), fidLog, 'ARCHIVE_RENAMED_HUMOR_HELPER');
        else
            fprintf('KEEP old HUMOR file still referenced: %s refs=%d\n', oldBase, refCount);
            fprintf(fidLog,'ARCHIVE_RENAMED_HUMOR_HELPER\tKEPT_STILL_REFERENCED\t%s\t\trefs=%d\n', src, refCount);
        end
    end
end

%% 3) Archive obvious zero-reference tiny leftovers
fprintf('\n--- 3) Archiving zero-reference leftovers ---\n');

[mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);
textsNoComments = readNoCommentTexts(mFiles);

% Zero-ref candidates observed after Phase 6 plus dynamic scan fallback.
explicitZeroCandidates = { ...
    'HUMOR_compact_chain_name.m', ...
    'deConfUSIon_make_loaded_display_name.m', ...
    'deConfUSIon_pcaica_scope_tag.m', ...
    'interpolateRejectedVolumes.m', ...
    'studio_mkdir.m', ...
    'deConfUSIon_phase6_fast_structural_cleanup.m', ...
    'deConfUSIon_phase6b_fc_noarg_patch.m' ...
};

for i = 1:numel(explicitZeroCandidates)
    src = fullfile(root, explicitZeroCandidates{i});
    if exist(src,'file') ~= 2
        continue;
    end

    [~,base,~] = fileparts(src);
    refCount = countRefsToBase(base, src, mFiles, textsNoComments);
    if refCount == 0
        moveWithArchive(src, fullfile(zeroRefDir, explicitZeroCandidates{i}), fidLog, 'ARCHIVE_ZERO_REF_EXPLICIT');
    else
        fprintf('KEEP explicit candidate still referenced: %s refs=%d\n', explicitZeroCandidates{i}, refCount);
        fprintf(fidLog,'ARCHIVE_ZERO_REF_EXPLICIT\tKEPT_REFERENCED\t%s\t\trefs=%d\n', src, refCount);
    end
end

% Dynamic root-level zero-ref candidates under 4 KB, excluding known entry/manual tools.
[mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);
textsNoComments = readNoCommentTexts(mFiles);

keepZeroRef = lower({ ...
    'deConfUSIon','run_deConfUSIon','run_fusi_studio', ...
    'readFileList','save_correct_colors','deConfUSIon_prepare_atlas', ...
    'deConfUSIon_apply_rgb2acr','deConfUSIon_reorder_FC_by_list', ...
    'deConfUSIon_fc_jm_order', ...
    'buildFooterLabel','addLog', ...
    'vfUSI_StimBox_TTL_EACH_FRAME_OR_TRIGGER_ACCESSORIES_COMMAND', ...
    'vfUSI_StimBox_TTL_EACH_FRAME_OR_TRIGGER_ACCESSORIES_OBJECT' ...
});

for i = 1:numel(mFiles)
    if ~strcmpi(mFolders{i}, root)
        continue;
    end

    base = mBases{i};
    if any(strcmpi(base, keepZeroRef))
        continue;
    end

    if ~isempty(regexpi(base,'callback|timer|popup|fullscreen|force_layout|remember_layout|registration|coreg','once'))
        continue;
    end

    inf = dir(mFiles{i});
    if isempty(inf) || inf.bytes > 4096
        continue;
    end

    refCount = countRefsToBase(base, mFiles{i}, mFiles, textsNoComments);
    if refCount == 0
        moveWithArchive(mFiles{i}, fullfile(zeroRefDir,[base '.m']), fidLog, 'ARCHIVE_ZERO_REF_DYNAMIC_SMALL');
    end
end

%% 4) Integrate tiny one-owner helpers now that old names are cleaned
fprintf('\n--- 4) Integrating remaining tiny one-owner helpers ---\n');

[mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);
textsRaw = readRawTexts(mFiles);
textsNoComments = readNoCommentTexts(mFiles);

mainKeep = lower({ ...
    'deConfUSIon','run_deConfUSIon','run_fusi_studio', ...
    'fusi_studio_GUI','fusi_studio_callback','fusi_studio_runtime', ...
    'FunctionalConnectivity','Segmentation','qc_fusi','filtering','motor','SCM_gui','mask', ...
    'pca_denoise','ica_denoise','loadFUSIData','GroupAnalysis','GroupAnalysis_Common', ...
    'GroupAnalysis_FC','GroupAnalysis_Map','coreg','coreg_3d','coreg_coronal_2d', ...
    'registration_ccf','registration_coronal_2d','readFileList','save_correct_colors', ...
    'deConfUSIon_prepare_atlas','deConfUSIon_apply_rgb2acr','deConfUSIon_reorder_FC_by_list', ...
    'deConfUSIon_fc_jm_order','addLog','buildFooterLabel','moveimage','play_fusi_video_final' ...
});

risky = 'callback|timer|popup|fullscreen|force_layout|remember_layout|registration|coreg|stimbox|ttl|accessories';

integrated = 0;
skipped = 0;
maxBytes = 5000;

% Build refs/owners
for ti = 1:numel(mFiles)
    helperPath = mFiles{ti};
    helperBase = mBases{ti};
    helperRel = mRels{ti};

    if ~strcmpi(mFolders{ti}, root)
        continue;
    end
    if any(strcmpi(helperBase, mainKeep))
        continue;
    end
    if ~isempty(regexpi(helperBase, risky, 'once'))
        continue;
    end

    inf = dir(helperPath);
    if isempty(inf) || inf.bytes > maxBytes
        continue;
    end

    raw = textsRaw{ti};
    if isempty(regexp(raw,'^\s*function','once','lineanchors'))
        continue;
    end

    helperFns = functionNamesInText(raw);
    if isempty(helperFns) || ~any(strcmp(helperFns, helperBase))
        continue;
    end

    owners = [];
    token = ['(?<![A-Za-z0-9_])' regexptranslate('escape',helperBase) '(?![A-Za-z0-9_])'];
    for si = 1:numel(mFiles)
        if si == ti, continue; end
        c = numel(regexp(textsNoComments{si}, token, 'match'));
        if c > 0
            owners(end+1) = si; %#ok<AGROW>
        end
    end
    owners = unique(owners);

    if numel(owners) ~= 1
        continue;
    end

    ownerIdx = owners(1);
    ownerPath = mFiles{ownerIdx};
    ownerRel = mRels{ownerIdx};
    ownerBase = mBases{ownerIdx};

    % Avoid integrating into non-root backup/other folders and avoid weird owners.
    if isempty(ownerPath) || exist(ownerPath,'file') ~= 2
        continue;
    end

    ownerRaw = fileread(ownerPath);
    ownerFns = functionNamesInText(ownerRaw);
    collision = intersect(lower(helperFns), lower(ownerFns));

    if ~isempty(collision)
        fprintf('SKIP integration collision: %s -> %s | %s\n', helperRel, ownerRel, strjoin(collision,','));
        fprintf(fidLog,'INTEGRATE_TINY\tSKIP_COLLISION\t%s\t%s\t%s\n', helperRel, ownerRel, strjoin(collision,','));
        skipped = skipped + 1;
        continue;
    end

    % Backup owner.
    backupOwner = fullfile(beforeEditDir, strrep(ownerRel,filesep,'__'));
    if exist(backupOwner,'file') ~= 2
        copyfile(ownerPath, backupOwner);
    end

    helperTxt = fileread(helperPath);
    newOwnerTxt = [ownerRaw sprintf('\n\n%%%% ------------------------------------------------------------------------\n') ...
        sprintf('%%%% Integrated tiny helper from %s on %s\n', helperRel, datestr(now)) ...
        sprintf('%%%% ------------------------------------------------------------------------\n\n') ...
        helperTxt sprintf('\n')];

    writeTextFile(ownerPath, newOwnerTxt);

    syntaxOK = true;
    syntaxMsg = '';
    if exist('mtree','file') == 2
        try
            mtree(ownerPath,'-file');
        catch ME
            syntaxOK = false;
            syntaxMsg = ME.message;
        end
    end

    if ~syntaxOK
        copyfile(backupOwner, ownerPath);
        fprintf('SKIP syntax failed, restored: %s -> %s | %s\n', helperRel, ownerRel, syntaxMsg);
        fprintf(fidLog,'INTEGRATE_TINY\tSKIP_SYNTAX_RESTORED\t%s\t%s\t%s\n', helperRel, ownerRel, syntaxMsg);
        skipped = skipped + 1;
        continue;
    end

    moveWithArchive(helperPath, fullfile(integratedDir, helperRel), fidLog, 'INTEGRATED_TINY_HELPER');
    fprintf('INTEGRATED tiny helper: %s -> %s\n', helperRel, ownerRel);
    fprintf(fidLog,'INTEGRATE_TINY\tINTEGRATED\t%s\t%s\t\n', helperRel, ownerRel);
    integrated = integrated + 1;

    % Refresh after each successful integration to avoid stale refs.
    [mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);
    textsRaw = readRawTexts(mFiles);
    textsNoComments = readNoCommentTexts(mFiles);
end

%% 5) Remove empty directories under safe areas and write final audit
fprintf('\n--- 5) Final audit ---\n');

removeEmptyDirsUnder(fullfile(root,'backups'), fidLog);
removeEmptyDirsUnder(fullfile(root,'cleanup_reports'), fidLog);
removeEmptyDirsUnder(fullfile(root,'bakcups'), fidLog);

[mFilesAfter, mBasesAfter, mRelsAfter, mFoldersAfter] = collectActiveMFiles(root); %#ok<ASGLU>
inventoryFile = fullfile(archiveRoot,'phase7_active_m_file_inventory.tsv');
fidInv = fopen(inventoryFile,'w');
fprintf(fidInv,'file\tpath\tbytes\n');
for i = 1:numel(mFilesAfter)
    inf = dir(mFilesAfter{i});
    fprintf(fidInv,'%s\t%s\t%d\n', mBasesAfter{i}, mRelsAfter{i}, inf.bytes);
end
fclose(fidInv);

smallFileReport = fullfile(archiveRoot,'phase7_remaining_small_files_under_2kb.tsv');
fidSmall = fopen(smallFileReport,'w');
fprintf(fidSmall,'file\tpath\tbytes\tactive_reference_count\n');
textsNoCommentsAfter = readNoCommentTexts(mFilesAfter);
for i = 1:numel(mFilesAfter)
    inf = dir(mFilesAfter{i});
    if inf.bytes <= 2048
        refCount = countRefsToBase(mBasesAfter{i}, mFilesAfter{i}, mFilesAfter, textsNoCommentsAfter);
        fprintf(fidSmall,'%s\t%s\t%d\t%d\n', mBasesAfter{i}, mRelsAfter{i}, inf.bytes, refCount);
    end
end
fclose(fidSmall);

% List remaining HUMOR names
remainingHumorFile = fullfile(archiveRoot,'phase7_remaining_HUMOR_named_files.tsv');
fidH = fopen(remainingHumorFile,'w');
fprintf(fidH,'file\tpath\tbytes\tactive_reference_count\n');
for i = 1:numel(mFilesAfter)
    if ~isempty(regexpi(mBasesAfter{i},'humor','once'))
        inf = dir(mFilesAfter{i});
        refCount = countRefsToBase(mBasesAfter{i}, mFilesAfter{i}, mFilesAfter, textsNoCommentsAfter);
        fprintf(fidH,'%s\t%s\t%d\t%d\n', mBasesAfter{i}, mRelsAfter{i}, inf.bytes, refCount);
    end
end
fclose(fidH);

removeBackupReportPaths(root);
addpath(root,'-begin');
rehash;
clear functions;

fprintf('\nDONE. Phase 7 final polish completed.\n');
fprintf('Active .m files before: %d\n', numel(mFiles));
fprintf('Active .m files after : %d\n', numel(mFilesAfter));
fprintf('Tiny helpers integrated: %d\n', integrated);
fprintf('Tiny helpers skipped   : %d\n', skipped);
fprintf('Archive/log folder     : %s\n', archiveRoot);
fprintf('Inventory              : %s\n', inventoryFile);
fprintf('Small-file report      : %s\n', smallFileReport);
fprintf('Remaining HUMOR report : %s\n', remainingHumorFile);

fprintf('\nNow test:\n');
fprintf('  deConfUSIon\n');
fprintf('  FunctionalConnectivity\n');
fprintf('  qc_fusi\n');

fprintf(fidLog,'SUMMARY\tDONE\tactive_before=%d\tactive_after=%d\tintegrated=%d\tskipped=%d\n', ...
    numel(mFiles), numel(mFilesAfter), integrated, skipped);
fclose(fidLog);

try, diary off; catch, end

%% =========================================================================
%% Helper functions
%% =========================================================================

function [mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root)
    rawDirs = regexp(genpath(root), pathsep, 'split');
    mFiles = {};
    mBases = {};
    mRels = {};
    mFolders = {};

    for di = 1:numel(rawDirs)
        d = rawDirs{di};
        if isempty(d), continue; end
        dl = lower(d);

        if pathHasPart(dl,'backups') || pathHasPart(dl,'bakcups') || ...
           pathHasPart(dl,'cleanup_reports') || pathHasPart(dl,'archived') || ...
           pathHasPart(dl,'.git') || pathHasPart(dl,'__macosx')
            continue;
        end

        ff = dir(fullfile(d,'*.m'));
        for k = 1:numel(ff)
            f = fullfile(d,ff(k).name);
            [~,b,~] = fileparts(ff(k).name);
            mFiles{end+1} = f; %#ok<AGROW>
            mBases{end+1} = b; %#ok<AGROW>
            mRels{end+1} = relativePath(f, root); %#ok<AGROW>
            mFolders{end+1} = d; %#ok<AGROW>
        end
    end
end

function tf = pathHasPart(p, part)
    sep = lower(filesep);
    part = lower(part);
    tf = ~isempty(strfind(p,[sep part sep])) || endsWithCompat(p,[sep part]);
end

function rel = relativePath(f, root)
    if numel(f) > numel(root)+1
        rel = f(numel(root)+2:end);
    else
        [~,n,e] = fileparts(f);
        rel = [n e];
    end
end

function removeBackupReportPaths(root)
    roots = {fullfile(root,'backups'), fullfile(root,'bakcups'), fullfile(root,'cleanup_reports')};
    for ri = 1:numel(roots)
        if exist(roots{ri},'dir') ~= 7, continue; end
        pp = regexp(genpath(roots{ri}), pathsep, 'split');
        for pi = 1:numel(pp)
            if isempty(pp{pi}), continue; end
            if ~isempty(strfind(path, pp{pi}))
                try, rmpath(pp{pi}); catch, end %#ok<CTCH>
            end
        end
    end
end

function texts = readRawTexts(files)
    texts = cell(size(files));
    for i = 1:numel(files)
        try
            texts{i} = fileread(files{i});
        catch
            texts{i} = '';
        end
    end
end

function texts = readNoCommentTexts(files)
    raw = readRawTexts(files);
    texts = cell(size(raw));
    for i = 1:numel(raw)
        texts{i} = stripMatlabComments(raw{i});
    end
end

function out = stripMatlabComments(txt)
    lines = regexp(txt, '\r\n|\n|\r', 'split');
    inBlock = false;
    for li = 1:numel(lines)
        line = lines{li};
        trimmed = strtrim(line);

        if startsWithCompat(trimmed,'%{')
            inBlock = true;
            lines{li} = '';
            continue;
        end
        if inBlock
            lines{li} = '';
            if startsWithCompat(trimmed,'%}')
                inBlock = false;
            end
            continue;
        end
        lines{li} = regexprep(line, '%.*$', '');
    end
    out = sprintf('%s\n', lines{:});
end

function n = countRefsToBase(base, selfPath, files, textsNoComments)
    tok = ['(?<![A-Za-z0-9_])' regexptranslate('escape',base) '(?![A-Za-z0-9_])'];
    n = 0;
    for i = 1:numel(files)
        if strcmpi(files{i}, selfPath)
            continue;
        end
        n = n + numel(regexp(textsNoComments{i}, tok, 'match'));
    end
end

function names = functionNamesInText(txt)
    toks = regexp(txt, ...
        '^\s*function\s+(?:\[[^\]]*\]\s*=\s*|[A-Za-z]\w*\s*=\s*)?([A-Za-z]\w*)', ...
        'tokens','lineanchors');
    names = {};
    for k = 1:numel(toks)
        if ~isempty(toks{k})
            names{end+1} = toks{k}{1}; %#ok<AGROW>
        end
    end
end

function writeTextFile(f, txt)
    fid = fopen(f,'w');
    if fid < 0
        error('Could not open for writing: %s', f);
    end
    fwrite(fid, txt);
    fclose(fid);
end

function moveWithArchive(src, dst, fidLog, action)
    if exist(src,'file') ~= 2 && exist(src,'dir') ~= 7
        fprintf('SKIP missing: %s\n', src);
        fprintf(fidLog,'%s\tMISSING\t%s\t%s\t\n', action, src, dst);
        return;
    end

    dstDir = fileparts(dst);
    if exist(dstDir,'dir') ~= 7
        mkdir(dstDir);
    end

    finalDst = dst;
    if exist(finalDst,'file') == 2 || exist(finalDst,'dir') == 7
        [p,n,e] = fileparts(dst);
        finalDst = fullfile(p,[n '_' datestr(now,'HHMMSSFFF') e]);
    end

    try
        movefile(src, finalDst);
        fprintf('MOVED: %s -> %s\n', src, finalDst);
        fprintf(fidLog,'%s\tMOVED\t%s\t%s\t\n', action, src, finalDst);
    catch ME
        fprintf('FAILED move: %s -> %s | %s\n', src, finalDst, ME.message);
        fprintf(fidLog,'%s\tFAILED\t%s\t%s\t%s\n', action, src, finalDst, ME.message);
    end
end

function removeEmptyDirsUnder(rootDir, fidLog)
    if exist(rootDir,'dir') ~= 7
        return;
    end
    dirs = regexp(genpath(rootDir), pathsep, 'split');
    [~,ord] = sort(cellfun(@numel, dirs), 'descend');
    dirs = dirs(ord);
    for i = 1:numel(dirs)
        d = dirs{i};
        if isempty(d) || strcmpi(d,rootDir) || exist(d,'dir') ~= 7
            continue;
        end
        L = dir(d);
        names = {L.name};
        names = setdiff(names,{'.','..'});
        if isempty(names)
            try
                rmdir(d);
                fprintf(fidLog,'REMOVE_EMPTY_DIR\tREMOVED\t%s\t\t\n', d);
            catch
            end
        end
    end
end

function tf = startsWithCompat(s, pat)
    tf = false;
    if numel(s) >= numel(pat)
        tf = strcmp(s(1:numel(pat)), pat);
    end
end

function tf = endsWithCompat(s, pat)
    tf = false;
    if numel(s) >= numel(pat)
        tf = strcmp(s(end-numel(pat)+1:end), pat);
    end
end
