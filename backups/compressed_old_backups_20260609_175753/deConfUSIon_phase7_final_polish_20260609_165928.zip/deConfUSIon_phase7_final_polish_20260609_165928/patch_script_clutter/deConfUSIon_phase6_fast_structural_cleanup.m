%% deConfUSIon PHASE 6 - aggressive but safe structural cleanup
% Author: ChatGPT
%
% Goal:
%   Reduce active .m file count by integrating SMALL helper functions that are
%   referenced by exactly ONE active owner file.
%
% Safety:
%   - Creates a full archive/backup folder first.
%   - Does NOT permanently delete anything.
%   - Does NOT integrate launchers, main GUIs, main analysis modules, atlas tools,
%     FC layout helpers, or risky timer/callback/autofit helpers.
%   - Skips helpers if function-name collisions are detected.
%   - If a syntax check fails after integration, restores the owner file and keeps
%     the helper external.
%
% Usage:
%   run('D:\Github\HUMOR-Analysis-Tool\deConfUSIon_phase6_fast_structural_cleanup.m')

clearvars -except root
clc

if exist('root','var') ~= 1 || isempty(root)
    root = 'D:\Github\HUMOR-Analysis-Tool';
end
root = char(regexprep(root,'[\\/]+$',''));

if exist(root,'dir') ~= 7
    error('Toolbox root not found: %s', root);
end

stamp = datestr(now,'yyyymmdd_HHMMSS');
archiveRoot = fullfile(root,'backups',['deConfUSIon_phase6_fast_cleanup_' stamp]);
beforeEditDir = fullfile(archiveRoot,'before_edit');
integratedDir = fullfile(archiveRoot,'integrated_helpers');
clutterDir = fullfile(archiveRoot,'patch_report_clutter');
dupDir = fullfile(archiveRoot,'shadowed_duplicate_files');
mkdir(archiveRoot);
mkdir(beforeEditDir);
mkdir(integratedDir);
mkdir(clutterDir);
mkdir(dupDir);

diaryFile = fullfile(archiveRoot,'phase6_console_log.txt');
try, diary(diaryFile); catch, end

fprintf('\n=== deConfUSIon PHASE 6: fast structural cleanup ===\n');
fprintf('ROOT   : %s\n', root);
fprintf('ARCHIVE: %s\n\n', archiveRoot);

logFile = fullfile(archiveRoot,'phase6_action_log.tsv');
fidLog = fopen(logFile,'w');
fprintf(fidLog,'action\tstatus\tsource\ttarget\tdetails\n');

%% Remove backup/report folders from MATLAB path to avoid shadowing
badPathRoots = { ...
    fullfile(root,'backups'), ...
    fullfile(root,'bakcups'), ...
    fullfile(root,'cleanup_reports') ...
};
for bi = 1:numel(badPathRoots)
    if exist(badPathRoots{bi},'dir') == 7
        pp = regexp(genpath(badPathRoots{bi}), pathsep, 'split');
        for pi = 1:numel(pp)
            if ~isempty(pp{pi})
                try, rmpath(pp{pi}); catch, end %#ok<CTCH>
            end
        end
    end
end
addpath(root,'-begin');

%% 1) Collect active .m files outside backups/reports/archive
[mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);
fprintf('Active .m files before cleanup: %d\n', numel(mFiles));

%% 2) Archive patch/report clutter from root
fprintf('\n--- Archiving patch/report clutter ---\n');

patchPatterns = { ...
    '^deConfUSIon_phase[0-5].*\.m$', ...
    '^deConfUSIon_.*cleanup.*\.m$', ...
    '^deConfUSIon_.*hotfix.*\.m$', ...
    '^deConfUSIon_.*repair.*\.m$', ...
    '^deConfUSIon_.*finalize.*\.m$', ...
    '^deConfUSIon_.*audit.*\.m$', ...
    '^deConfUSIon_cleanup_report\.md$', ...
    '^file_reference_.*\.tsv$', ...
    '^zero_active_reference_candidates\.tsv$', ...
    '^duplicate_.*\.tsv$', ...
    '^JM_atlas_color_order_integration_report\.txt$' ...
};

rootFiles = dir(root);
for i = 1:numel(rootFiles)
    if rootFiles(i).isdir, continue; end
    nm = rootFiles(i).name;

    % never archive the current script while it is running
    if strcmpi(nm,'deConfUSIon_phase6_fast_structural_cleanup.m')
        continue;
    end

    shouldMove = false;
    for p = 1:numel(patchPatterns)
        if ~isempty(regexpi(nm, patchPatterns{p}, 'once'))
            shouldMove = true;
            break;
        end
    end

    if shouldMove
        moveWithArchive(fullfile(root,nm), fullfile(clutterDir,nm), fidLog, 'PATCH_REPORT_CLUTTER');
    end
end

% Move old cleanup_reports and misspelled bakcups into this archive
if exist(fullfile(root,'cleanup_reports'),'dir') == 7
    moveWithArchive(fullfile(root,'cleanup_reports'), fullfile(clutterDir,'cleanup_reports'), fidLog, 'CLEANUP_REPORTS_DIR');
end
if exist(fullfile(root,'bakcups'),'dir') == 7
    moveWithArchive(fullfile(root,'bakcups'), fullfile(clutterDir,'bakcups'), fidLog, 'MISSPELLED_BAKCUPS_DIR');
end

%% Refresh active files after clutter removal
[mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);

%% 3) Archive shadowed duplicate .m files when a root-level version exists
fprintf('\n--- Archiving shadowed duplicate .m files ---\n');

[uniqueBases,~,grp] = unique(lower(mBases));
for gi = 1:numel(uniqueBases)
    idx = find(grp == gi);
    if numel(idx) <= 1, continue; end

    rootIdx = [];
    for j = 1:numel(idx)
        if strcmpi(mFolders{idx(j)}, root)
            rootIdx(end+1) = idx(j); %#ok<AGROW>
        end
    end

    if isempty(rootIdx)
        fprintf('DUPLICATE kept for review, no root master: %s\n', mBases{idx(1)});
        fprintf(fidLog,'DUPLICATE_REVIEW\tNO_ROOT_MASTER\t%s\t\t%s\n', mBases{idx(1)}, strjoin(mRels(idx),'; '));
        continue;
    end

    for j = 1:numel(idx)
        ii = idx(j);
        if any(rootIdx == ii), continue; end

        src = mFiles{ii};
        dst = fullfile(dupDir, mRels{ii});
        moveWithArchive(src, dst, fidLog, 'SHADOWED_DUPLICATE_M_FILE');
    end
end

%% Refresh active files after duplicate cleanup
[mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root);

%% 4) Build reference graph
fprintf('\n--- Building reference graph ---\n');

textsNoComments = cell(size(mFiles));
textsRaw = cell(size(mFiles));
for i = 1:numel(mFiles)
    try
        textsRaw{i} = fileread(mFiles{i});
    catch
        textsRaw{i} = '';
    end
    textsNoComments{i} = stripMatlabComments(textsRaw{i});
end

refCounts = zeros(numel(mFiles),1);
refOwners = cell(numel(mFiles),1);

for ti = 1:numel(mFiles)
    targetBase = mBases{ti};
    tok = ['(?<![A-Za-z0-9_])' regexptranslate('escape',targetBase) '(?![A-Za-z0-9_])'];

    owners = [];
    total = 0;

    for si = 1:numel(mFiles)
        if si == ti, continue; end
        c = numel(regexp(textsNoComments{si}, tok, 'match'));
        if c > 0
            owners(end+1) = si; %#ok<AGROW>
            total = total + c;
        end
    end

    refCounts(ti) = total;
    refOwners{ti} = owners;
end

%% 5) Select one-owner small helper candidates for integration
fprintf('\n--- Selecting one-owner helper candidates ---\n');

% Main/entry/risky files that should remain standalone
keepExact = lower({ ...
    'deConfUSIon','run_deConfUSIon','run_fusi_studio', ...
    'fusi_studio_GUI','fusi_studio_callback','fusi_studio_runtime', ...
    'FunctionalConnectivity','Segmentation','qc_fusi','filtering','motor', ...
    'SCM_gui','mask','pca_denoise','ica_denoise','loadFUSIData', ...
    'GroupAnalysis','GroupAnalysis_FC','GroupAnalysis_Map','GroupAnalysis_Common', ...
    'coreg','coreg_3d','coreg_coronal_2d','registration_ccf','registration_coronal_2d', ...
    'deConfUSIon_prepare_atlas','deConfUSIon_apply_rgb2acr','deConfUSIon_reorder_FC_by_list', ...
    'deConfUSIon_fc_jm_order','readFileList','save_correct_colors', ...
    'addLog','buildFooterLabel','moveimage','play_fusi_video_final' ...
});

riskyRegex = [ ...
    '(^|_)force_layout$|' ...
    '(^|_)remember_layout$|' ...
    'popup_autofit|popup_polish|fullscreen|timer|' ...
    'callback|stimbox|ttl|accessories|' ...
    'param_gui|imregdemons_param|registration_|coreg|' ...
    '^run_|^deConfUSIon$'];

maxBytes = 12000;  % focus on small helper files, but allow enough for useful helpers

candidateIdx = [];
skipReasons = containers.Map('KeyType','char','ValueType','char');

for i = 1:numel(mFiles)
    base = mBases{i};
    baseLower = lower(base);
    info = dir(mFiles{i});
    if isempty(info), continue; end

    if any(strcmp(baseLower, keepExact))
        skipReasons(base) = 'keep exact/main entry';
        continue;
    end

    if ~strcmpi(mFolders{i}, root)
        skipReasons(base) = 'not root level';
        continue;
    end

    if ~isempty(regexpi(base, riskyRegex, 'once'))
        skipReasons(base) = 'risky name/callback/layout/timer';
        continue;
    end

    if info.bytes > maxBytes
        skipReasons(base) = sprintf('too large (%d bytes)', info.bytes);
        continue;
    end

    raw = textsRaw{i};
    if isempty(regexp(raw,'^\s*function','once','lineanchors'))
        skipReasons(base) = 'not a function file';
        continue;
    end

    declared = functionNamesInText(raw);
    if isempty(declared)
        skipReasons(base) = 'no function declarations parsed';
        continue;
    end

    if ~any(strcmp(declared, base))
        skipReasons(base) = 'primary function does not match file name';
        continue;
    end

    if ~isempty(regexpi(raw,'classdef|mex|javaaddpath|addlistener|TimerFcn|CreateFcn|DeleteFcn','once'))
        skipReasons(base) = 'risky contents';
        continue;
    end

    owners = unique(refOwners{i});
    if numel(owners) ~= 1
        skipReasons(base) = sprintf('owner count = %d', numel(owners));
        continue;
    end

    ownerBase = mBases{owners(1)};
    if strcmpi(ownerBase, base)
        skipReasons(base) = 'self owner only';
        continue;
    end

    candidateIdx(end+1) = i; %#ok<AGROW>
end

fprintf('One-owner helper candidates selected: %d\n', numel(candidateIdx));

candFile = fullfile(archiveRoot,'phase6_selected_integration_candidates.tsv');
fidCand = fopen(candFile,'w');
fprintf(fidCand,'helper\towner\tbytes\tdeclared_functions\n');
for ci = 1:numel(candidateIdx)
    ii = candidateIdx(ci);
    oi = unique(refOwners{ii});
    info = dir(mFiles{ii});
    fprintf(fidCand,'%s\t%s\t%d\t%s\n', mRels{ii}, mRels{oi(1)}, info.bytes, strjoin(functionNamesInText(textsRaw{ii}),','));
end
fclose(fidCand);

%% 6) Integrate candidates, grouped by owner, with collision checks
fprintf('\n--- Integrating selected helpers into their single owner ---\n');

integratedCount = 0;
skippedCollision = 0;
skippedSyntax = 0;

% process owners in descending candidate file size? no, simple order
for ci = 1:numel(candidateIdx)
    helperIdx = candidateIdx(ci);

    % helper may already have been moved after refresh? verify
    helperPath = mFiles{helperIdx};
    helperRel = mRels{helperIdx};
    helperBase = mBases{helperIdx};

    if exist(helperPath,'file') ~= 2
        fprintf('SKIP helper missing: %s\n', helperRel);
        fprintf(fidLog,'INTEGRATE_HELPER\tSKIP_MISSING\t%s\t\t\n', helperRel);
        continue;
    end

    owners = unique(refOwners{helperIdx});
    if numel(owners) ~= 1
        fprintf('SKIP owner changed: %s\n', helperRel);
        fprintf(fidLog,'INTEGRATE_HELPER\tSKIP_OWNER_CHANGED\t%s\t\t\n', helperRel);
        continue;
    end

    ownerIdx = owners(1);
    ownerPath = mFiles{ownerIdx};
    ownerRel = mRels{ownerIdx};
    ownerBase = mBases{ownerIdx};

    if exist(ownerPath,'file') ~= 2
        fprintf('SKIP owner missing: %s owner=%s\n', helperRel, ownerRel);
        fprintf(fidLog,'INTEGRATE_HELPER\tSKIP_OWNER_MISSING\t%s\t%s\t\n', helperRel, ownerRel);
        continue;
    end

    helperTxt = fileread(helperPath);
    ownerTxt = fileread(ownerPath);

    helperFns = functionNamesInText(helperTxt);
    ownerFns = functionNamesInText(ownerTxt);

    collision = intersect(lower(helperFns), lower(ownerFns));
    if ~isempty(collision)
        fprintf('SKIP collision: %s -> %s | %s\n', helperRel, ownerRel, strjoin(collision,','));
        fprintf(fidLog,'INTEGRATE_HELPER\tSKIP_COLLISION\t%s\t%s\t%s\n', helperRel, ownerRel, strjoin(collision,','));
        skippedCollision = skippedCollision + 1;
        continue;
    end

    % Avoid integrating if helper contains common local names already integrated into owner
    if numel(helperFns) ~= numel(unique(lower(helperFns)))
        fprintf('SKIP duplicate names inside helper: %s\n', helperRel);
        fprintf(fidLog,'INTEGRATE_HELPER\tSKIP_DUPLICATE_NAMES_INSIDE_HELPER\t%s\t%s\t\n', helperRel, ownerRel);
        skippedCollision = skippedCollision + 1;
        continue;
    end

    % Backup owner once per current content
    safeOwnerRel = strrep(ownerRel, filesep, '__');
    ownerBackup = fullfile(beforeEditDir, safeOwnerRel);
    if exist(ownerBackup,'file') ~= 2
        copyfile(ownerPath, ownerBackup);
    end

    helperBackup = fullfile(integratedDir, helperRel);
    helperBackupDir = fileparts(helperBackup);
    if exist(helperBackupDir,'dir') ~= 7, mkdir(helperBackupDir); end

    appended = sprintf('\n\n%%%% ------------------------------------------------------------------------\n%%%% Integrated helper from %s on %s\n%%%% Original file archived in backups/deConfUSIon_phase6_fast_cleanup_*/integrated_helpers\n%%%% ------------------------------------------------------------------------\n\n%s\n', ...
        helperRel, datestr(now), helperTxt);

    newOwnerTxt = [ownerTxt appended];

    % Write and syntax-check
    fidW = fopen(ownerPath,'w');
    fwrite(fidW, newOwnerTxt);
    fclose(fidW);

    syntaxOK = true;
    syntaxMsg = '';
    if exist('mtree','file') == 2
        try
            mtree(ownerPath,'-file');
        catch ME
            syntaxOK = false;
            syntaxMsg = ME.message;
        end
    end

    if ~syntaxOK
        copyfile(ownerBackup, ownerPath);
        fprintf('SKIP syntax failed, restored owner: %s -> %s | %s\n', helperRel, ownerRel, syntaxMsg);
        fprintf(fidLog,'INTEGRATE_HELPER\tSKIP_SYNTAX_RESTORED\t%s\t%s\t%s\n', helperRel, ownerRel, syntaxMsg);
        skippedSyntax = skippedSyntax + 1;
        continue;
    end

    % Move helper file away after owner passes syntax check
    moveWithArchive(helperPath, helperBackup, fidLog, 'INTEGRATED_HELPER_ARCHIVED');

    fprintf('INTEGRATED: %s -> %s\n', helperRel, ownerRel);
    fprintf(fidLog,'INTEGRATE_HELPER\tINTEGRATED\t%s\t%s\t\n', helperRel, ownerRel);
    integratedCount = integratedCount + 1;

    % Refresh this owner's text representation in memory for collision checks
    textsRaw{ownerIdx} = newOwnerTxt;
    textsNoComments{ownerIdx} = stripMatlabComments(newOwnerTxt);
end

%% 7) Remove empty folders under root, except root/backups parent
fprintf('\n--- Removing empty folders under backups/reports/archive-safe areas ---\n');

% only remove empty directories under backups and root-level cleanup clutter areas,
% never arbitrary toolbox source directories.
emptyRemoved = 0;
safeEmptyRoots = {fullfile(root,'backups'), fullfile(root,'cleanup_reports'), fullfile(root,'bakcups')};
for sri = 1:numel(safeEmptyRoots)
    sr = safeEmptyRoots{sri};
    if exist(sr,'dir') ~= 7, continue; end

    dirs = regexp(genpath(sr), pathsep, 'split');
    % deepest first
    [~,order] = sort(cellfun(@numel, dirs), 'descend');
    dirs = dirs(order);

    for di = 1:numel(dirs)
        d = dirs{di};
        if isempty(d) || strcmpi(d,sr), continue; end
        if exist(d,'dir') ~= 7, continue; end
        content = dir(d);
        names = {content.name};
        names = setdiff(names,{'.','..'});
        if isempty(names)
            try
                rmdir(d);
                emptyRemoved = emptyRemoved + 1;
                fprintf(fidLog,'REMOVE_EMPTY_DIR\tREMOVED\t%s\t\t\n', d);
            catch
            end
        end
    end
end

fprintf('Empty folders removed: %d\n', emptyRemoved);

%% 8) Final inventory
fprintf('\n--- Final inventory ---\n');

[mFilesAfter, mBasesAfter, mRelsAfter, mFoldersAfter] = collectActiveMFiles(root); %#ok<ASGLU>
inventoryFile = fullfile(archiveRoot,'phase6_active_m_file_inventory.tsv');
fidInv = fopen(inventoryFile,'w');
fprintf(fidInv,'file\tpath\tbytes\n');
for i = 1:numel(mFilesAfter)
    inf = dir(mFilesAfter{i});
    fprintf(fidInv,'%s\t%s\t%d\n', mBasesAfter{i}, mRelsAfter{i}, inf.bytes);
end
fclose(fidInv);

smallFileReport = fullfile(archiveRoot,'phase6_remaining_small_files_under_2kb.tsv');
fidSmall = fopen(smallFileReport,'w');
fprintf(fidSmall,'file\tpath\tbytes\treason_not_integrated_or_status\n');
for i = 1:numel(mFilesAfter)
    inf = dir(mFilesAfter{i});
    if inf.bytes <= 2048
        reason = '';
        if isKey(skipReasons, mBasesAfter{i})
            reason = skipReasons(mBasesAfter{i});
        end
        fprintf(fidSmall,'%s\t%s\t%d\t%s\n', mBasesAfter{i}, mRelsAfter{i}, inf.bytes, reason);
    end
end
fclose(fidSmall);

%% Clean path and finish
for bi = 1:numel(badPathRoots)
    if exist(badPathRoots{bi},'dir') == 7
        pp = regexp(genpath(badPathRoots{bi}), pathsep, 'split');
        for pi = 1:numel(pp)
            if ~isempty(pp{pi})
                try, rmpath(pp{pi}); catch, end %#ok<CTCH>
            end
        end
    end
end
addpath(root,'-begin');
rehash;
clear functions;

fprintf('\nDONE. Phase 6 cleanup complete.\n');
fprintf('Active .m files before: %d\n', numel(mFiles));
fprintf('Active .m files after : %d\n', numel(mFilesAfter));
fprintf('Integrated helpers    : %d\n', integratedCount);
fprintf('Skipped collisions    : %d\n', skippedCollision);
fprintf('Skipped syntax        : %d\n', skippedSyntax);
fprintf('Archive/log folder    : %s\n', archiveRoot);
fprintf('Candidate report      : %s\n', candFile);
fprintf('Small-file report     : %s\n', smallFileReport);
fprintf('Inventory             : %s\n', inventoryFile);

fprintf('\nNow test:\n');
fprintf('  deConfUSIon\n');
fprintf('  FunctionalConnectivity\n');
fprintf('  qc_fusi\n');

fprintf(fidLog,'SUMMARY\tDONE\tactive_before=%d\tactive_after=%d\tintegrated=%d;collision=%d;syntax=%d\n', ...
    numel(mFiles), numel(mFilesAfter), integratedCount, skippedCollision, skippedSyntax);
fclose(fidLog);

try, diary off; catch, end

%% =========================================================================
%% Local helper functions
%% =========================================================================

function [mFiles, mBases, mRels, mFolders] = collectActiveMFiles(root)
    rawDirs = regexp(genpath(root), pathsep, 'split');

    mFiles = {};
    mBases = {};
    mRels = {};
    mFolders = {};

    for di = 1:numel(rawDirs)
        d = rawDirs{di};
        if isempty(d), continue; end

        dl = lower(d);
        skip = false;
        skip = skip || containsPathPart(dl,'backups');
        skip = skip || containsPathPart(dl,'bakcups');
        skip = skip || containsPathPart(dl,'cleanup_reports');
        skip = skip || containsPathPart(dl,'archived');
        skip = skip || containsPathPart(dl,'.git');
        skip = skip || containsPathPart(dl,'__macosx');

        if skip, continue; end

        ff = dir(fullfile(d,'*.m'));
        for k = 1:numel(ff)
            f = fullfile(d,ff(k).name);
            [~,b,~] = fileparts(ff(k).name);

            if numel(f) > numel(root)+1
                rel = f(numel(root)+2:end);
            else
                rel = ff(k).name;
            end

            mFiles{end+1} = f; %#ok<AGROW>
            mBases{end+1} = b; %#ok<AGROW>
            mRels{end+1} = rel; %#ok<AGROW>
            mFolders{end+1} = d; %#ok<AGROW>
        end
    end
end

function tf = containsPathPart(pathLower, partLower)
    sep = lower(filesep);
    partLower = lower(partLower);
    tf = false;
    tf = tf || ~isempty(strfind(pathLower, [sep partLower sep]));
    tf = tf || endsWithCompat(pathLower, [sep partLower]);
end

function tf = endsWithCompat(s, pat)
    tf = false;
    if numel(s) >= numel(pat)
        tf = strcmp(s(end-numel(pat)+1:end), pat);
    end
end

function out = stripMatlabComments(txt)
    lines = regexp(txt, '\r\n|\n|\r', 'split');
    inBlock = false;
    for li = 1:numel(lines)
        line = lines{li};
        trimmed = strtrim(line);

        if startsWithCompat(trimmed,'%{')
            inBlock = true;
            lines{li} = '';
            continue;
        end

        if inBlock
            lines{li} = '';
            if startsWithCompat(trimmed,'%}')
                inBlock = false;
            end
            continue;
        end

        lines{li} = regexprep(line, '%.*$', '');
    end
    out = sprintf('%s\n', lines{:});
end

function tf = startsWithCompat(s, pat)
    tf = false;
    if numel(s) >= numel(pat)
        tf = strcmp(s(1:numel(pat)), pat);
    end
end

function names = functionNamesInText(txt)
    toks = regexp(txt, ...
        '^\s*function\s+(?:\[[^\]]*\]\s*=\s*|[A-Za-z]\w*\s*=\s*)?([A-Za-z]\w*)', ...
        'tokens','lineanchors');
    names = {};
    for k = 1:numel(toks)
        if ~isempty(toks{k})
            names{end+1} = toks{k}{1}; %#ok<AGROW>
        end
    end
end

function moveWithArchive(src, dst, fidLog, action)
    if exist(src,'file') ~= 2 && exist(src,'dir') ~= 7
        fprintf('SKIP missing: %s\n', src);
        fprintf(fidLog,'%s\tMISSING\t%s\t%s\t\n', action, src, dst);
        return;
    end

    dstDir = fileparts(dst);
    if exist(dstDir,'dir') ~= 7
        mkdir(dstDir);
    end

    % Avoid overwrite by adding suffix
    finalDst = dst;
    if exist(finalDst,'file') == 2 || exist(finalDst,'dir') == 7
        [p,n,e] = fileparts(dst);
        finalDst = fullfile(p, [n '_' datestr(now,'HHMMSSFFF') e]);
    end

    try
        movefile(src, finalDst);
        fprintf('MOVED: %s -> %s\n', src, finalDst);
        fprintf(fidLog,'%s\tMOVED\t%s\t%s\t\n', action, src, finalDst);
    catch ME
        fprintf('FAILED move: %s -> %s | %s\n', src, finalDst, ME.message);
        fprintf(fidLog,'%s\tFAILED\t%s\t%s\t%s\n', action, src, finalDst, ME.message);
    end
end
