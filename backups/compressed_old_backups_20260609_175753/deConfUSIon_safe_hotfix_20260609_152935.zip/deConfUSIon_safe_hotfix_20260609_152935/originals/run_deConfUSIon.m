function run_deConfUSIon()
%RUN_DECONFUSION Launch deConfUSIon using the stable fUSI Studio entry point.
run_fusi_studio;
end
