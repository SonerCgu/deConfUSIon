function deConfUSIon()
%DECONFUSION Launch deConfUSIon.
run_deConfUSIon;
end
