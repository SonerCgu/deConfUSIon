%% deConfUSIon PHASE 5 deep cleanup
% Goal: reduce active .m files safely.
% Actions:
%   1) integrate helper files that are referenced only by one core script
%   2) flatten simple forwarding wrappers where behavior is unchanged
%   3) archive old HUMOR/HUMoR leftovers with zero active references
%   4) archive root-level manual/patch/report clutter
%   5) remove empty backup/report folders
%
% This script archives, never permanently deletes.
% Tested for MATLAB R2017b-style local functions in scripts.

root = 'D:\Github\HUMOR-Analysis-Tool';
root = regexprep(root,'[\\/]+$','');

stamp = datestr(now,'yyyymmdd_HHMMSS');
archiveRoot = fullfile(root,'backups',['deConfUSIon_phase5_deep_cleanup_' stamp]);
beforeEditDir = fullfile(archiveRoot,'before_edit');
integratedDir = fullfile(archiveRoot,'integrated_helpers');
legacyDir = fullfile(archiveRoot,'legacy_zero_ref');
manualDir = fullfile(archiveRoot,'manual_or_report_clutter');
mkdir(archiveRoot); mkdir(beforeEditDir); mkdir(integratedDir); mkdir(legacyDir); mkdir(manualDir);

logFile = fullfile(archiveRoot,'phase5_deep_cleanup_log.tsv');
fidLog = fopen(logFile,'w');
fprintf(fidLog,'action\tfile\tdestination\tstatus\tdetails\n');

fprintf('\n=== deConfUSIon PHASE 5 deep cleanup ===\n');
fprintf('ROOT   : %s\n',root);
fprintf('ARCHIVE: %s\n\n',archiveRoot);

% Keep backup/report folders off path during refactor.
localRemoveBackupPaths(root);
addpath(root,'-begin');

% -------------------------------------------------------------------------
% A) Build active file index
% -------------------------------------------------------------------------
activeFiles = localListActiveMFiles(root);
fprintf('Active .m files before cleanup: %d\n',numel(activeFiles));

% -------------------------------------------------------------------------
% B) Integrate helpers referenced only by one core script/group
% -------------------------------------------------------------------------
% Do NOT include deConfUSIon_FC_force_layout/deConfUSIon_FC_remember_layout here;
% they contain duplicate localGet-style helpers and are intentionally left external.
integrationGroups = {};

integrationGroups{end+1} = struct( ...
    'core','FunctionalConnectivity.m', ...
    'helpers',{{ ...
        'fc_compare_slice_note.m', ...
        'fc_label_mask_for_slice.m', ...
        'fc_region_names_from_region_struct.m', ...
        'fc_slice_filter_text.m', ...
        'deConfUSIon_FC_build_slice_bundle.m', ...
        'deConfUSIon_FC_make_slice_roi_result.m', ...
        'deConfUSIon_FC_slice_keep_indices.m', ...
        'deConfUSIon_FC_stepmotor_read_folder.m', ...
        'deConfUSIon_fc_jm_order.m' ...
    }});

integrationGroups{end+1} = struct( ...
    'core','qc_fusi.m', ...
    'helpers',{{ ...
        'deConfUSIon_force_png_white_background.m', ...
        'deConfUSIon_style_rejected_qc_axis.m' ...
    }});

integrationGroups{end+1} = struct( ...
    'core','fusi_studio_GUI.m', ...
    'helpers',{{ ...
        'studio_mkdir.m', ...
        'deConfUSIon_pcaica_scope_tag.m', ...
        'deConfUSIon_make_loaded_display_name.m', ...
        'interpolateRejectedVolumes.m' ...
    }});

integrationGroups{end+1} = struct( ...
    'core','Segmentation.m', ...
    'helpers',{{ ...
        'deConfUSIon_apply_region_names_to_region.m' ...
    }});

for gi = 1:numel(integrationGroups)
    group = integrationGroups{gi};
    corePath = fullfile(root,group.core);
    if exist(corePath,'file') ~= 2
        fprintf('SKIP integration group, core missing: %s\n',group.core);
        fprintf(fidLog,'INTEGRATE_GROUP\t%s\t\tSKIP_CORE_MISSING\t\n',group.core);
        continue;
    end

    for hi = 1:numel(group.helpers)
        helperRel = group.helpers{hi};
        helperPath = fullfile(root,helperRel);
        if exist(helperPath,'file') ~= 2
            fprintf('SKIP helper missing/already integrated: %s\n',helperRel);
            fprintf(fidLog,'INTEGRATE_HELPER\t%s\t\tSKIP_MISSING\t\n',helperRel);
            continue;
        end

        [~,helperBase] = fileparts(helperRel);
        refs = localReferenceFiles(root, helperBase);
        refs = setdiff(refs, {helperRel}, 'stable');

        % Allowed references: core itself and helpers in same group.
        allowed = [{group.core}, group.helpers];
        notAllowed = setdiff(refs, allowed, 'stable');
        if ~isempty(notAllowed)
            fprintf('KEEP shared helper: %s (also referenced by %s)\n',helperRel,strjoin(notAllowed,'; '));
            fprintf(fidLog,'INTEGRATE_HELPER\t%s\t\tKEEP_SHARED\t%s\n',helperRel,strjoin(notAllowed,'; '));
            continue;
        end

        helperFns = localFunctionDeclarations(helperPath);
        coreFns = localFunctionDeclarations(corePath);
        mainAlreadyInCore = any(strcmp(helperBase, coreFns));
        conflicts = intersect(helperFns, coreFns, 'stable');

        if mainAlreadyInCore
            % Already integrated in a previous phase. Archive the path-visible copy.
            dst = fullfile(integratedDir,helperRel);
            localMoveFile(helperPath,dst,fidLog,'ARCHIVE_ALREADY_INTEGRATED');
            fprintf('ARCHIVED already-integrated helper copy: %s\n',helperRel);
            continue;
        end

        if ~isempty(conflicts)
            fprintf('SKIP integration due local-function name conflict: %s | %s\n',helperRel,strjoin(conflicts,', '));
            fprintf(fidLog,'INTEGRATE_HELPER\t%s\t\tSKIP_FUNCTION_NAME_CONFLICT\t%s\n',helperRel,strjoin(conflicts,', '));
            continue;
        end

        % Backup core once per helper append; simple and safe.
        localBackupFile(corePath,beforeEditDir,root);

        try
            coreTxt = fileread(corePath);
            helperTxt = fileread(helperPath);
            helperTxt = strrep(helperTxt,sprintf('\r\n'),sprintf('\n'));
            marker = sprintf('\n\n%%%% ===== Integrated helper from %s on %s =====\n',helperRel,datestr(now));
            fidCore = fopen(corePath,'a');
            fprintf(fidCore,'%s%s\n',marker,helperTxt);
            fclose(fidCore);

            dst = fullfile(integratedDir,helperRel);
            localMoveFile(helperPath,dst,fidLog,'INTEGRATED_INTO_CORE');
            fprintf('INTEGRATED: %s -> %s\n',helperRel,group.core);
        catch ME
            fprintf('FAILED integrating %s -> %s | %s\n',helperRel,group.core,ME.message);
            fprintf(fidLog,'INTEGRATE_HELPER\t%s\t%s\tFAILED\t%s\n',helperRel,group.core,ME.message);
        end
    end
end

rehash; clear functions;
activeFiles = localListActiveMFiles(root);

% -------------------------------------------------------------------------
% C) Flatten safe forwarding wrappers
% -------------------------------------------------------------------------
% deConfUSIon_canonical_dataset_label simply forwards to deConfUSIon_ordered_chain_label,
% whose nargin defaults are equivalent for current use.
forwardMap = { ...
    'deConfUSIon_canonical_dataset_label','deConfUSIon_ordered_chain_label' ...
};

for mi = 1:size(forwardMap,1)
    oldName = forwardMap{mi,1};
    newName = forwardMap{mi,2};
    oldPath = fullfile(root,[oldName '.m']);
    newPath = fullfile(root,[newName '.m']);
    if exist(oldPath,'file') ~= 2 || exist(newPath,'file') ~= 2
        continue;
    end

    edited = 0;
    filesNow = localListActiveMFiles(root);
    for fi = 1:numel(filesNow)
        f = filesNow{fi};
        [~,base] = fileparts(f);
        if strcmp(base,oldName), continue; end
        try, txt = fileread(f); catch, continue; end
        oldTxt = txt;
        pat = ['(?<![A-Za-z0-9_])' regexptranslate('escape',oldName) '(?![A-Za-z0-9_])'];
        txt = regexprep(txt,pat,newName);
        if ~strcmp(txt,oldTxt)
            localBackupFile(f,beforeEditDir,root);
            fid = fopen(f,'w'); fwrite(fid,txt); fclose(fid);
            edited = edited + 1;
        end
    end

    refsLeft = localReferenceFiles(root,oldName);
    refsLeft = setdiff(refsLeft,{[oldName '.m']},'stable');
    if isempty(refsLeft)
        dst = fullfile(legacyDir,[oldName '.m']);
        localMoveFile(oldPath,dst,fidLog,'FLATTENED_FORWARDER_ARCHIVED');
        fprintf('FLATTENED forwarder: %s -> %s; edited files=%d\n',oldName,newName,edited);
    else
        fprintf('KEEP forwarder still referenced: %s by %s\n',oldName,strjoin(refsLeft,'; '));
        fprintf(fidLog,'FLATTEN_FORWARDER\t%s\t\tKEEP_STILL_REFERENCED\t%s\n',oldName,strjoin(refsLeft,'; '));
    end
end

rehash; clear functions;

% -------------------------------------------------------------------------
% D) Archive old HUMOR/HUMoR leftovers that are now unreferenced or only
%    reference each other.
% -------------------------------------------------------------------------
hFiles = [dir(fullfile(root,'HUMOR*.m')); dir(fullfile(root,'HUMoR*.m'))];
for hi = 1:numel(hFiles)
    oldRel = hFiles(hi).name;
    oldPath = fullfile(root,oldRel);
    [~,oldBase] = fileparts(oldRel);
    refs = localReferenceFiles(root,oldBase);
    refs = setdiff(refs,{oldRel},'stable');

    % If all references are from other HUMOR/HUMoR files, it is stale legacy chain.
    nonHumorRefs = {};
    for ri = 1:numel(refs)
        [~,rb] = fileparts(refs{ri});
        if isempty(regexpi(rb,'^HUMO[Rr]_','once')) && isempty(regexpi(rb,'^HUMoR_','once'))
            nonHumorRefs{end+1} = refs{ri}; %#ok<AGROW>
        end
    end

    if isempty(refs) || isempty(nonHumorRefs)
        dst = fullfile(legacyDir,oldRel);
        localMoveFile(oldPath,dst,fidLog,'ARCHIVED_LEGACY_HUMOR_LEFTOVER');
        fprintf('ARCHIVED legacy HUMOR leftover: %s\n',oldRel);
    else
        fprintf('KEEP HUMOR file still externally referenced: %s by %s\n',oldRel,strjoin(nonHumorRefs,'; '));
        fprintf(fidLog,'LEGACY_HUMOR\t%s\t\tKEEP_REFERENCED\t%s\n',oldRel,strjoin(nonHumorRefs,'; '));
    end
end

% -------------------------------------------------------------------------
% E) Archive root-level patch/report/manual clutter, but only if unreferenced.
% -------------------------------------------------------------------------
manualCandidates = { ...
    'save_correct_colors.m', ...
    'deConfUSIon_reorder_FC_by_list.m', ...
    'deConfUSIon_phase4_structural_cleanup.m', ...
    'deConfUSIon_phase5_deep_cleanup.m', ...
    'deConfUSIon_cleanup_patch.m', ...
    'deConfUSIon_repair_after_cleanup.m', ...
    'deConfUSIon_safe_hotfix_cleanup_atlas.m', ...
    'deConfUSIon_finalize_cleanup_and_atlas_auto.m', ...
    'deConfUSIon_finalize_cleanup_and_atlas_auto_v2.m' ...
};

for ci = 1:numel(manualCandidates)
    rel = manualCandidates{ci};
    p = fullfile(root,rel);
    if exist(p,'file') ~= 2, continue; end
    [~,base] = fileparts(rel);
    refs = localReferenceFiles(root,base);
    refs = setdiff(refs,{rel},'stable');
    if isempty(refs)
        dst = fullfile(manualDir,rel);
        localMoveFile(p,dst,fidLog,'ARCHIVED_MANUAL_OR_PATCH_CLUTTER');
        fprintf('ARCHIVED manual/patch clutter: %s\n',rel);
    else
        fprintf('KEEP manual/patch file still referenced: %s by %s\n',rel,strjoin(refs,'; '));
        fprintf(fidLog,'MANUAL_PATCH\t%s\t\tKEEP_REFERENCED\t%s\n',rel,strjoin(refs,'; '));
    end
end

% Move old top-level report folders into this archive. They are not active code.
reportFolders = {'cleanup_reports','bakcups'};
for ri = 1:numel(reportFolders)
    rp = fullfile(root,reportFolders{ri});
    if exist(rp,'dir') == 7
        dst = fullfile(manualDir,reportFolders{ri});
        try
            movefile(rp,dst);
            fprintf('MOVED report/old backup folder: %s\n',reportFolders{ri});
            fprintf(fidLog,'MOVE_FOLDER\t%s\t%s\tMOVED\t\n',reportFolders{ri},dst);
        catch ME
            fprintf('FAILED moving folder %s | %s\n',reportFolders{ri},ME.message);
            fprintf(fidLog,'MOVE_FOLDER\t%s\t%s\tFAILED\t%s\n',reportFolders{ri},dst,ME.message);
        end
    end
end

% Archive obvious root-level zip/rar/md cleanup artifacts if present.
extraPatterns = {'deConfUSIon_*package*.zip','deConfUSIon_*report*.md','matlab_functions.rar'};
for pi = 1:numel(extraPatterns)
    dd = dir(fullfile(root,extraPatterns{pi}));
    for di = 1:numel(dd)
        if dd(di).isdir, continue; end
        rel = dd(di).name;
        p = fullfile(root,rel);
        dst = fullfile(manualDir,rel);
        localMoveFile(p,dst,fidLog,'ARCHIVED_ROOT_ARTIFACT');
        fprintf('ARCHIVED root artifact: %s\n',rel);
    end
end

% -------------------------------------------------------------------------
% F) Remove empty directories under backups/manual report areas only.
% -------------------------------------------------------------------------
removedDirs = localRemoveEmptyDirs(fullfile(root,'backups'), archiveRoot);
fprintf('Removed empty backup/report directories: %d\n',removedDirs);
fprintf(fidLog,'REMOVE_EMPTY_DIRS\tbackups\t\tDONE\t%d removed\n',removedDirs);

% Final path/cache refresh.
localRemoveBackupPaths(root);
addpath(root,'-begin');
atlasTools = fullfile(root,'atlas_tools');
if exist(atlasTools,'dir') == 7, addpath(atlasTools,'-begin'); end
rehash; clear functions;

activeAfter = localListActiveMFiles(root);
fprintf('\nDONE. Phase 5 deep cleanup completed.\n');
fprintf('Active .m files after cleanup: %d\n',numel(activeAfter));
fprintf('Reduced by: %d active .m files\n',numel(activeFiles)-numel(activeAfter));
fprintf('Archive/log folder:\n%s\n',archiveRoot);
fprintf('Log file:\n%s\n',logFile);

fprintf('\nRecommended tests now:\n');
fprintf('  which deConfUSIon\n');
fprintf('  which FunctionalConnectivity\n');
fprintf('  which qc_fusi\n');
fprintf('  deConfUSIon\n');

fclose(fidLog);

%% ========================================================================
function localRemoveBackupPaths(root)
    bad = {fullfile(root,'backups'), fullfile(root,'bakcups'), fullfile(root,'cleanup_reports')};
    for i = 1:numel(bad)
        if exist(bad{i},'dir') == 7
            pp = regexp(genpath(bad{i}), pathsep, 'split');
            for j = 1:numel(pp)
                if ~isempty(pp{j})
                    try, rmpath(pp{j}); catch, end
                end
            end
        end
    end
end

function files = localListActiveMFiles(root)
    dirs = regexp(genpath(root), pathsep, 'split');
    files = {};
    for di = 1:numel(dirs)
        d = dirs{di};
        if isempty(d), continue; end
        dl = lower(d);
        skip = false;
        skip = skip || ~isempty(strfind(dl,[filesep 'backups']));
        skip = skip || ~isempty(strfind(dl,[filesep 'bakcups']));
        skip = skip || ~isempty(strfind(dl,[filesep 'cleanup_reports']));
        skip = skip || ~isempty(strfind(dl,[filesep 'archived']));
        skip = skip || ~isempty(strfind(dl,[filesep '.git']));
        skip = skip || ~isempty(strfind(dl,[filesep '__macosx']));
        if skip, continue; end
        ff = dir(fullfile(d,'*.m'));
        for k = 1:numel(ff)
            files{end+1} = fullfile(d,ff(k).name); %#ok<AGROW>
        end
    end
end

function refs = localReferenceFiles(root, baseName)
    files = localListActiveMFiles(root);
    refs = {};
    token = ['(?<![A-Za-z0-9_])' regexptranslate('escape',baseName) '(?![A-Za-z0-9_])'];
    for i = 1:numel(files)
        f = files{i};
        try
            txt = fileread(f);
        catch
            txt = '';
        end
        lines = regexp(txt,'\r\n|\n|\r','split');
        for li = 1:numel(lines)
            lines{li} = regexprep(lines{li},'%.*$','');
        end
        cleanTxt = sprintf('%s\n',lines{:});
        if ~isempty(regexp(cleanTxt,token,'once'))
            refs{end+1} = strrep(f,[root filesep],''); %#ok<AGROW>
        end
    end
end

function names = localFunctionDeclarations(filePath)
    names = {};
    if exist(filePath,'file') ~= 2, return; end
    try
        txt = fileread(filePath);
    catch
        return;
    end
    toks = regexp(txt,'^\s*function\s+(?:\[[^\]]*\]\s*=\s*|[A-Za-z]\w*\s*=\s*)?([A-Za-z]\w*)','tokens','lineanchors');
    for i = 1:numel(toks)
        names{end+1} = toks{i}{1}; %#ok<AGROW>
    end
    names = unique(names,'stable');
end

function localBackupFile(filePath,beforeEditDir,root)
    if exist(filePath,'file') ~= 2, return; end
    rel = strrep(filePath,[root filesep],'');
    relSafe = strrep(rel,filesep,'__');
    dst = fullfile(beforeEditDir,relSafe);
    if exist(dst,'file') == 2, return; end
    try, copyfile(filePath,dst); catch, end
end

function localMoveFile(src,dst,fidLog,action)
    if exist(src,'file') ~= 2
        fprintf(fidLog,'%s\t%s\t%s\tMISSING\t\n',action,src,dst);
        return;
    end
    dstDir = fileparts(dst);
    if exist(dstDir,'dir') ~= 7, mkdir(dstDir); end
    try
        movefile(src,dst);
        fprintf(fidLog,'%s\t%s\t%s\tMOVED\t\n',action,src,dst);
    catch ME
        fprintf(fidLog,'%s\t%s\t%s\tFAILED\t%s\n',action,src,dst,ME.message);
    end
end

function n = localRemoveEmptyDirs(startDir, protectDir)
    n = 0;
    if exist(startDir,'dir') ~= 7, return; end
    allDirs = regexp(genpath(startDir), pathsep, 'split');
    allDirs = allDirs(~cellfun('isempty',allDirs));
    % deepest first
    [~,ord] = sort(cellfun(@numel,allDirs),'descend');
    allDirs = allDirs(ord);
    protectDir = char(protectDir);
    for i = 1:numel(allDirs)
        d = allDirs{i};
        if strcmpi(d,startDir) || strcmpi(d,protectDir), continue; end
        if strncmpi(d,protectDir,numel(protectDir)), continue; end
        try
            content = dir(d);
            names = {content.name};
            names = setdiff(names,{'.','..'});
            if isempty(names)
                rmdir(d);
                n = n + 1;
            end
        catch
        end
    end
end
